<?php $getarr = get_option('ab_gpt3_content_settings');
    $lang = isset($getarr['language']) ? $getarr['language'] : '';
    $writing_style = isset($getarr['writing_style']) ? $getarr['writing_style'] : '';
    $writing_tone = isset($getarr['writing_tone']) ? $getarr['writing_tone'] : '';
    $number_of_heading = isset($getarr['number_of_heading']) ? $getarr['number_of_heading'] : '';
    $Heading_tag = isset($getarr['Heading_tag']) ? $getarr['Heading_tag'] : '';
    $modify_heading = isset($getarr['modify_heading']) ? $getarr['modify_heading'] : '';
    $getcheckArray = isset($getarr['check_Arr']) ? $getarr['check_Arr'] : ''; 
    $cslist = isset($getarr['cs_list']) ? $getarr['cs_list'] : '';
    $langArr =  array(
        'English',  'Bulgarian', 'Czech', 'Danish', 'German', 'Greek', 'British', 'English(American)', 'Spanish', 'Estonian', 'Finnish', 'French', 'Hungarian', 'Indonesian', 'Italian', 'Japanese', 'Korean', 'Lithuanian', 'Latvian', 'Norwegian (Bokmål)', 'Dutch', 'Polish', 'Portuguese', 'Portuguese (Brazilian)','Romanian', 'Russian', 'Slovak', 'Slovenian', 'Swedish', 'Turkish', 'Ukrainian', 'Chinese' );
    $writingStyleArr = array('Creative', 'Informal','Academic','Business','Creative','Journalistic','Scientific');
    $writingToneArr = array('Funny','Casual', 'Excited', 'Professional', 'Witty', 'Sarcastic', 'Feminine', 'Masculine', 'Bold', 'Dramatic', 'Grumpy', 'Secretive'); 
    $subhedingArr = array('H2','H3','H4','H5'); 
    $checkArr  = array(
                        'addkeywordBold' => 'Format Keywords in Bold:-',
                        'addinsertToc' => 'Insert TOC',
                        'addinsertHyper' => 'Identify Suitable Text to Add Hyperlinks :- ',                 
                     );



?>
<link rel="stylesheet" href="<?php echo plugins_url('ai-scribe-gpt-article-builder/templates/article_builder.css');?>">
<style type="text/css">
.article-main.overlay{
    position: relative;
}
.article-main.overlay::before {
    content: '';
    width: 100%;
    height: 100%;
    position: absolute;
    background-image: url('<?php echo plugins_url('ai-scribe-gpt-article-builder/assets/spinener.gif');?>');
    background-repeat: no-repeat;
    background-position: center center;
    left: 0;
    right: 0;
    opacity: 0.5;
    z-index: 99999;
}

 @media screen and (max-width: 768px) {
    .overlay{
    display: block;
}
 }
</style>
<link href="https://cdn.quilljs.com/1.2.6/quill.snow.css" rel="stylesheet">
<script src="https://cdn.quilljs.com/1.2.6/quill.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" />
<div class="create_template_cont_sec">
    <center><img class="opace-logo" src=" <?php echo plugins_url('ai-scribe-gpt-article-builder/assets/2023/03/AI-Scribe-Logo-simplified.png');?>" alt="opace logo"></center>
    <!-- header-start -->
    <div class="article_header">
       
     <header>
        <div class="header-main">
            <div class="temp-progress-bar progress-bar">
                <div data-step="1" class="step active_step">
                 <p>Brainstorm<br/>Titles</p>
                 <div class="bullet nav-step"> <span>1</span> </div>
                    
                </div><div data-step="2" id="keywordnav" class="step">
                <p>Identify<br/>Keywords</p>
                <div class="bullet nav-step"> <span >2</span> </div>
                </div>
                <div data-step="3" class="step">
                  <p>Generate<br/>Outline</p>
                  <div class="bullet nav-step"> <span >3</span> </div>
                    <div class="check fas fa-check"></div>
                </div>
                <div data-step="4" class="step">
               <p>Create<br/>Intro</p>
               <div class="bullet nav-step"> <span >4</span> </div> 
                    <div class="check fas fa-check"></div>
                </div>
                <div data-step="5" class="step">
               <p>Add<br/>Tagline</p>
               <div class="bullet nav-step"> <span >5</span> </div> 
                    <div class="check fas fa-check"></div>
                </div>
                <div data-step="6" class="step article_nav">
                <p>Create<br/>Main Body</p>
                <div class="bullet nav-step"> <span >6</span> </div>
                    <div class="check fas fa-check"></div>
                </div>
                <div data-step="7" class="step">
               <p>Build<br/>Conclusion</p>
               <div class="bullet nav-step"> <span >7</span> </div> 
                    <div class="check fas fa-check"></div>
                </div>
                <div data-step="8" class="step" id="qnaBar">
              <p>Add<br/>Q&amp;A's</p>
              <div class="bullet nav-step"> <span >8</span> </div>
                    <div class="check fas fa-check"></div>
                </div>
                <div data-step="9" class="step">
                <p>Build<br/>Meta Data</p>
                <div class="bullet nav-step"> <span id="metaPosition" >9</span> </div>
                    <div class="check fas fa-check"></div>
                </div>
                <div data-step="10" class="step">
               <p>View<br/>&amp; Publish</p>
               <div class="bullet nav-step"> <span >10</span> </div>
                    <div class="check fas fa-check"></div>
                </div>
                <div data-step="11" class="step">
                 <p>Evaluate<br/>&amp; Enhance</p>
                 <div class="bullet nav-step"> <span >11</span> </div>
                    <div class="check fas fa-check"></div>
                </div>
            </div>
        </div>
    </header>
    </div>
    <!-- header-end -->

        <div class="article-main">
			
    <div class="progress-container" style="display:none;">
        <h2>AI is currently writing the article for you.</h2>
        <p class="pro-p">Please keep this page open until the process is completed. It can take up to 2 minutes.</p>

        <div id="Progress">
          <div id="progressBar"><b>7%</b></div>
        </div>
    </div>
            <div class="article-left">
                <!-- title-start -->
                <div class="main-common at_temp_sec at_temp_sec_1 active_step " id="step1">
                    <h1 class="bratop-headingin">
						
                    Brainstorm Article Title Ideas  
                    </h1>
                    <div class="maincontent">
                    <div class="title_div  genrate">
                    <input class="keywords action_val_field " type="text" id="tab_input" name="tab_input" placeholder=" Add your article title idea here...." />
                        <button data-action="title" class="btn tab_generate_btn">
                        Generate
                        </button>
                         </div>
                    <div>
                    <label for=""><h2 class="label-last">Select a title for your article</h2>  </label>
                    <div class="main-div3 title_class">
                    <div class="title-idea">
                        <ul class="ul1">
                            Please wait, your results will show here...   
                        </ul>
                    </div>
                    </div>
                    <div class="skip_cont_div">
                    <button class="btn generate_more_btn" data-action="title" generate-more="generate_more" >Generate more</button>
                    <button class="btn next_step_btn" data-nextstep="2" auto-generate = 'cont_next_step'>Continue</button>
                    </div>
                    </div>
                    </div>
                </div>
                <!-- title-end -->
                <!-- Keywords-start -->
                   <div class="main-common at_temp_sec at_temp_sec_2" id="step2" style="display:none;">
                        <h1 class="top-heading">
                        Find Relevant Keywords Automatically
                        </h1>
                        <div class="closest-obj">
                             <button class="btn next_step_btn" data-nextstep="1" id="keywordback" back-btn="back">BACK</button> 
                                <div class="maincontent">
                                        <div class="genrate_input_sec" style="display:none;">  
                                            <input class="keywords action_val_field" type="text" id="tab_keyword"  name="tab_keyword" placeholder=" Add your keyword ideas here..."/>
                                            <button class="btn tab_generate_btn" data-action="keyword">Generate</button>
                                        </div>
                                        <label for=""><h2 class="label-last">Your previous selections</h2>  </label>
                                        <div class="title-idea checked-element" id="keycheckedval">
                                        <ul class="ul1">
                                            <h2 class="">Your checked value show here... </h2>   
                                        </ul>
                                    </div>  
                                    <div>
                                        <label for=""><h2 class="label-last">Select keywords for your article</h2>  </label>
                                        <div class="title_class ">
                                            <div class="title-idea">
                                            <ul class="ul1">
                                                Please wait, your results will show here...   
                                            </ul>
                                        </div>
                                        </div>
                                        <div class="skip_cont_div">
                                            <button class="btn next_step_btn" data-nextstep="3" skip-btn="skip">Skip</button>
                                            <button class="btn generate_more_btn" data-action="keyword" generate-more="generate_more">Generate More</button>
                                            <button class="btn next_step_btn" data-nextstep="3" auto-generate = 'cont_next_step' >Continue</button>
                                        </div>
                                    </div>
                                </div>
                        </div>
                    </div>
                <!-- Keywords-end -->
                
                <!-- Outline-start -->
                 <div class="main-common at_temp_sec at_temp_sec_3" id="step3" style="display:none;">
                    <h3 class="top-heading">
                        SUGGEST AN ARTICLE OUTLINE AND SECTION HEADINGS  
                    </h3>
                    <div class="parentmain-div2">
                        <div class="closest-obj">
                            <button class="btn next_step_btn" data-nextstep="2" back-btn="back">BACK</button>
                            <div class="maincontent">
                                 <div class="genrate_input_sec" style="display:none;">
                                    <textarea class="inputtt action_val_field " placeholder="Add your outline idea here" name="w3review" ></textarea>
                                    <button class="btn tab_generate_btn" data-action="heading">Generate</button>
                                     </div> 
                                     <label for=""><h2 class="label-last">Your previous selections</h2>  </label>
                                        <div class="title-idea checked-element">
                                        <ul class="ul1">
                                            <h2>Your checked value show here... </h2>   
                                        </ul>
                                    </div>
                                <label for=""><h2 class="label-last">Select below if you are happy with the article outline</h2>  </label>
                                <div class="main-div3 title_class">
                                    <div class="title-idea">
                                    <ul class="ul1">
                                        Please wait, your results will show here...   
                                    </ul>
                                </div>
                                </div>
                                <div class="skip_cont_div">
                                    <button class="btn next_step_btn" data-nextstep="4" skip-btn="skip">Skip</button>
                                    <button class="btn generate_more_btn" data-action="heading" generate-more="generate_more">Generate More</button>
                                    <button class="btn next_step_btn" data-nextstep="4"  auto-generate = 'cont_next_step'>Continue</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Outline-end -->
                <!-- Intro -strat -->
                <div class="main-common at_temp_sec at_temp_sec_4" id="step4" style="display:none;">
                    <h3 class="top-heading">
                         Generate Intro  
                    </h3>
                    <div class="closest-obj">
                        <div class="introo">
                            <button class="btn next_step_btn" data-nextstep="3" back-btn="back">BACK</button>
                            <div class="maincontent">
                            <div class="genrate_input_sec" style="display:none;">
                            <textarea id="w3review" name="w3review" class="action_val_field" placeholder="Add your intro idea here" rows="5" cols="40"></textarea>
                            <button class="btn tab_generate_btn" data-action="intro"  >Generate Intro</button>
                             
                            </div>
                            <label for=""><h2 class="label-last">Your previous selections</h2>  </label>
                            <div class="title-idea checked-element">
                            <ul class="ul1">
                                <h2>Your checked value show here... </h2>   
                            </ul>
                        </div>
                           
                        <div>
                            <label for=""><h2 class="label-last">Select below if you are happy with the introduction</h2>  </label>
                            <div class="title_class">
                              <div class="title-idea">
                                <ul class="ul1">
                                    Please wait, your results will show here...   
                                </ul>
                            </div>  
                            </div>
                            <div class="skip_cont_div">
                                <button class="btn next_step_btn" data-nextstep="5" skip-btn="skip">Skip</button>
                                <button class="btn tab_regenerate_btn" regenerate="regenerateAttr">Regenerate</button>
                                <button class="btn next_step_btn" data-nextstep="5" auto-generate = 'cont_next_step'>Continue</button>
                            </div>
                        </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Intro-end -->
                 
                <!-- Tagline-start -->
                 <div class="main-common at_temp_sec at_temp_sec_5" id="step5" style="display:none;">
                    <h3 class="top-heading">
                         Generate Tagline: A short headline to go above or below the Introduction  
                    </h3>
                    <div class="closest-obj">
                        <div class="introo">
                            <button class="btn next_step_btn" data-nextstep="4" back-btn="back">BACK</button>
                            <div class="maincontent">
                            <div class="genrate_input_sec" style="display:none;">
                            <textarea id="w3review1" class="action_val_field" placeholder="Add your tagline idea here" name="w3review" rows="5" cols="40"></textarea>
                            <button class="btn tab_generate_btn" data-action="tagline">Generate </button>
                             </div>
                             <label for=""><h2 class="label-last">Your previous selections</h2>  </label>
                             <div class="title-idea checked-element">
                                <ul class="ul1">
                                    <h2>Your checked value show here... </h2>   
                                </ul>
                            </div>
                            <div>
                                <label for=""><h2 class="label-last">Select below if you would like to add a tagline</h2>  </label>
                                <div class="title_class">
                                   <div class="title-idea">
                                    <ul class="ul1">
                                        Please wait, your results will show here...   
                                    </ul>
                                </div>
                                </div>
                            </div>
                            <div>
                                <ul class="ul2">
                                    <li > Above Intro <input class="checkbox above_below" name="above_below_tagline" value="above" type="radio"> </li>
                                    <li > Below Intro <input class="checkbox above_below" name="above_below_tagline" value="below" type="radio" checked="checked"> </li>
                                </ul>
                            </div>

                            <div class="skip_cont_div">
                                <button class="btn next_step_btn tagline_skip_btn" data-nextstep="6" skip-btn="skip">Skip</button>
                                <button class="btn tab_regenerate_btn" regenerate="regenerateAttr">Regenerate</button>
                                <button class="btn next_step_btn tagline_btn" data-nextstep="6" auto-generate = 'cont_next_step'>Continue</button>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
                <!-- Tagline-end -->
               
                <!-- Article-start -->
                 <div class="main-common at_temp_sec at_temp_sec_6" id="step6" style="display:none;">
                    <h3 class="top-heading">
                         Generate Main Body  
                    </h3>
                    <div class="closest-obj">
                        <div>
                            <button class="btn next_step_btn" data-nextstep="5" back-btn="back">BACK</button>
                        </div> 
                        <label for=""><h2 class="label-last">Your previous selections</h2>  </label>
                        <div class="title-idea checked-element">
                            
                        </div>
                        <div class="maincontent" >
                            <style>
                                .editorjs .ql-editor ul > li::before {
                                    content: '';
                                    width: 0px;
                                } 
                            </style>
                            <div class="genrate_input_sec" style="display:none;">
                            <textarea id="w3review1" class="action_val_field" placeholder="Add your tagline idea here" name="w3review" rows="5" cols="40"></textarea>
                            <button class="btn tab_generate_btn" data-action="article">Generate </button>
                             </div>
                            <label for=""><h2 class="label-last">Here is the main body of your article</h2>  </label>
							<div class="editorjs">
                                    <div class="title-idea checked-element">
                                     <div class="title_class intro-test">
                                    <div class="ul1">
                                       Your result will show here...
                                    </div>   
                                </div>
                              </div> 
                               </div>
                            <div class="skip_cont_div" data-action="article">
                                <button class="btn tab_regenerate_btn" regenerate="regenerateAttr">Regenerate</button>
                                <button class="btn next_step_btn" data-nextstep="7" auto-generate = 'cont_next_step'>Continue</button>
                            </div>
                       
                        </div>
                        
                    </div>
                </div>
                <!-- Article-end -->
                 
                <!-- Conclusion-start -->
                 <div class="main-common at_temp_sec at_temp_sec_7" id="step7" style="display:none;">
                    <h3 class="top-heading">
                         Conclusion  
                    </h3>
                    <div class="closest-obj">
                        <div class="maincontent">
                        <div class="conclusion">
                            <button class="btn next_step_btn" data-nextstep="6" back-btn="back">BACK </button>

                            <button class="btn tab_generate_btn" data-action="conclusion" style="display:none;">Generate Conclusion </button> </div>      
                            <label for=""><h2 class="label-last">Your previous selections</h2>  </label>
                            <div class="title-idea checked-element">
                            <ul class="ul1">
                                <h2>Your checked value show here... </h2>   
                            </ul>
                        </div>
                        <label for=""><h2 class="label-last">Select below if you would like to add a conclusion</h2>  </label>
                            <div class="title_class intro-test">
                                <div class="title-idea">
                                <ul class="ul1">
                                    Please wait, your results will show here...   
                                </ul>
                            </div>
                            </div>
                            <div>
                                
                            </div>
                            <div class="skip_cont_div">
                                <button class="btn next_step_btn" data-nextstep="8" id="conclusionSkip" skip-btn="skip">Skip</button>
                                <button class="btn tab_regenerate_btn" regenerate="regenerateAttr">Regenerate</button>
                                <button class="btn next_step_btn" id="conclusionCont" data-nextstep="8" auto-generate = 'cont_next_step'>Continue</button>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Conclusion-end -->
                 
                <!-- Question-start -->
                 <div class="main-common at_temp_sec at_temp_sec_8" id="step8" style="display:none;">
                    <h3 class="top-heading">
                         Generate Related Question and Answer  
                    </h3>
                    <div class="closest-obj">
                        <div class="maincontent">
                            <div>
                                <button class="btn next_step_btn" data-nextstep="7" back-btn="back">BACK </button>
                                <button class="btn tab_generate_btn" data-action="qna" style="display:none;">Generate Q&amp;As </button>
                            </div> 
                            <label for=""><h2 class="label-last">Your previous selections</h2>  </label>     
                            <div class="title-idea checked-element">
                            <ul class="ul1">
                                <h2>Your checked value show here... </h2>   
                            </ul>
                        </div>
                        <label for=""><h2 class="label-last">Select the below Q&amp;A's if you would like to include them</h2>  </label>
                            <div class="title_class intro-test">
                              <div class="title-idea">
                                <ul class="ul1">
                                    Please wait, your results will show here...   
                                </ul>
                            </div>  
                            </div>
                            <div>
                                <ul class="ul2">
                                    <li> Above the conclusion <input class="checkbox above_below_conclusion" name="above_below_conclusion" value="above" type="radio"> </li>
                                    <li> Below the conclusion <input class="checkbox above_below_conclusion" name="above_below_conclusion" value="below" type="radio" checked="checked"> </li>
                                </ul>
                            </div>
                            <div class="skip_cont_div">
                                <button class="btn next_step_btn" data-nextstep="9" skip-btn="skip">Skip</button>
                                <button class="btn tab_regenerate_btn" regenerate="regenerateAttr">Regenerate</button>
                                <button class="btn next_step_btn" data-nextstep="9" auto-generate = 'cont_next_step'>Continue</button>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Question-end -->
                  
                <!-- Meta-Data-start -->
                <div class="main-common at_temp_sec at_temp_sec_9" id="step9" style="display:none;">
                    <h3 class="top-heading">
                         Generate SEO Meta Data  
                    </h3>
                    <div class="closest-obj">
                        <div class="maincontent">
                            <div>
                                <button class="btn next_step_btn" data-nextstep="8" id="metadataBack" back-btn="back">BACK</button>
                                <button class="btn tab_generate_btn" data-action="seo-meta-data" style="display:none;">Generate Meta Data</button>
                            </div>   
                            <label for=""><h2 class="label-last">Your previous selections</h2>  </label>   
                            <div class="title-idea checked-element">
                            <ul class="ul1">
                                <h2>Your checked value show here... </h2>   
                            </ul>
                        </div>
                            <label for=""><h2 class="label-last">Finally, select below if you would like to add Meta Data</h2>  </label>
                            <div class="title_class intro-test">
                               <div class="title-idea">
                                <ul class="ul1">
                                    Please wait, your results will show here...   
                                </ul>
                            </div> 
                            </div>    
                            <div class="skip_cont_div">
                                    <button class="btn next_step_btn review_skip_btn" data-nextstep="10" skip-btn="skip">Skip</button>
                                    <button class="btn  tab_regenerate_btn" regenerate="regenerateAttr">Regenerate</button>
                                    <button class="btn next_step_btn meta-data-btn" data-nextstep="10" auto-generate = 'cont_next_step'>Continue</button>
                                </div>
                        </div>
                    </div>
                </div>
                <!-- Meta-Data-end -->
                 
                <!-- Review & Publish Article-start -->
                 <div class="main-common at_temp_sec at_temp_sec_10" id="step10" style="display:none;">
                    <h3 class="top-heading">
                         REVIEW  &amp; PUBLISH  ARTICLE 
                    </h3>
                    <div class="closest-obj">
                        <div class="maincontent">
                            <button class="btn next_step_btn" data-nextstep="9" back-btn="back">BACK</button>      
                            <button class="btn tab_generate_btn" data-action="review" style="display:none;">Generate Meta Data</button>
                            <label for=""><h2 class="label-last">Your Article</h2>  </label>
                            
                                <style>
                                .editorjs2 .ql-editor ul > li::before {
                                    content: '';
                                    width: 0px;
                                } 
                            </style>
                                  
                                <div class="editorjs2 ">
                                    <div class="title-idea checked-element">
                                     <div class="title_class intro-test">
                                    <div class="ul1">
                                        
                                       Your result will show here...
                                    </div>   
                                </div>
                              </div> 
                               </div>
                            <div class="skip_cont_div">
                                <button class="btn next_step_btn"  data-nextstep="11" auto-generate = 'cont_next_step'>Evaluate My article</button>
                                <button class="btn save_post_tab">Save as post(Draft)</button>
                                <button class="btn save_as_shortcode">Save as shortcode</button>
                            </div>
                           
                        
                    </div>
                </div>
            </div>
                <!-- Review & Public Article-end -->
                <div class="main-common at_temp_sec at_temp_sec_11" id="step11" style="display:none;">
                    <h3 class="top-heading">
                         Evaluate &amp; Enhance  
                    </h3>
                    <div class="closest-obj">
                        <div> <button class="btn next_step_btn" data-nextstep="10" back-btn="back"> BACK </button>       </div>      
                        <div class="maincontent">
                            <button class="btn tab_generate_btn" data-action="evaluate" style="display:none;">Generate Q&amp;As </button>

                            <div class="title_class intro-test">
                                     
                                </div>    
                            <div>
                                <?php 
                                    $current_page = admin_url( "admin.php?page=saved_shortcodes" );
                                     
                                ?>
                                <a href="<?php echo $current_page; ?>"> <button class="btn">Exit</button></a>
                             
                                 </div>
                        </div>
                    </div>
                </div>
            </div>

                <div class="article-right">
                    <div class="option-prompt">
                    <h1>OPTIONS &amp; PROMPTS</h1>
                    <P>The below options will be enabled where appropriate at each stage of the wizard.</P>
                    </div>
                        <div class="main-common2">
                             <div class="lang-additional-heading">
                                <div class="container div-main">
                                    <h1>
                                    <div class="bullet" ></div><span class="plus-sign languages_style_tab" style="cursor: pointer;">+</span> Language, Style & Tone
                                    </h1>
                                    <div class=" languages_style" style="display:none;">
                                        <form class="form1" action="#">
                                        <div class="formgroup languages">
                                             <label for="lang">  Languages:-   </label> <select name="languages" id="lang">
                                            <option value=""  disabled >Select Language</option> <?php foreach ($langArr as $langkey => $langvalue) { 
                                            $selected="";
                                            if($langvalue == $lang){
                                            $selected="selected";
                                            }                       
                                            ?> <option <?php echo $selected; ?> value="<?php echo $langvalue; ?>"><?php echo $langvalue; ?></option> <?php 
                                            } ?>
                                            </select> 
                                            
                                        </div>
                                        <div class="formgroup1">
                                             <label for="writingStyle">  Writing Style:-   </label> <select name="writingStyle" id="writingStyle">
                                            <option value=""  disabled >Select Writing Style</option> <?php foreach ($writingStyleArr as $writingStyleArrkey => $writingStyleArrvalue) { 
                                            $selected="";
                                            if($writingStyleArrvalue == $writing_style){
                                            $selected="selected";
                                            }                       
                                            ?> <option <?php echo $selected; ?> value="<?php echo $writingStyleArrvalue; ?>"><?php echo $writingStyleArrvalue; ?></option> <?php 
                                            } ?>
                                            </select> 
                                           
                                        </div>
                                        <div class="formgroup1">
                                             <label for="writingTone">  Writing Tone:-   </label> <select name="writingTone" id="writingTone">
                                            <option value=""  disabled >Select Writing Tone</option> <?php foreach ($writingToneArr as $writingToneArrkey => $writingToneArrvalue) { 
                                            $selected="";
                                            if($writingToneArrvalue == $writing_tone){
                                            $selected="selected";
                                            }                       
                                            ?> <option <?php echo $selected; ?> value="<?php echo $writingToneArrvalue; ?>"><?php echo $writingToneArrvalue; ?></option> <?php 
                                            } ?>
                                            </select> 
                                          
                                        </div>
                                    </form>
                                    </div>
                                </div>
                                 <!--  -->
                                <div class="container heading-div1">
                                    <h1>
                                    <div class="bullet " >  </div><span class="plus-sign heading_tab" style="cursor: pointer;">+</span>
                                    
                                    Headings
                                    </h1>
                                    <div class=" hide_headings_tab" style="display:none;" >
                                             <form class="form1 headingcont" action="#">
                                            <div class="formgroup1 heading_key_avoid no_heading">
                                                <label for="lang"> Number of Headings:-   </label> <input class="heading-no" type="text" name="num_heading" id="" value="<?php echo $number_of_heading; ?>" />
                                            </div>
                                            <div class="formgroup1">
                                                 <label for="lang">  Heading Tags:-   </label> <select name="headingtag" id="heading-tag">
                                                <option value="" disabled >Select Heading Tags</option> <?php foreach ($subhedingArr as $subhedingArrkey => $subhedingArrvalue) { 
                                                $selected="";
                                                if($subhedingArrvalue == $Heading_tag){
                                                $selected="selected";
                                                }                       
                                                ?> <option <?php echo $selected; ?> value="<?php echo $subhedingArrvalue; ?>"><?php echo $subhedingArrvalue; ?></option> <?php 
                                                } ?>
                                                </select>
                                            </div>  
                                         </form>
                                    </div> 
                                </div>
                                <!--  -->
                                <div class="container" style="display:none;">
                                    <h1>
                                    <div class="bullet " >  </div><span class="plus-sign additional_content_tab" style="cursor: pointer;">+</span> Additional Content
                                    </h1>
                                    <div class="hide_addition_content"  >
                                        <form class="form1" action="#">
                                        <div class="formgroup1 heading_key_avoid"> <label for="lang"> Keywords to Avoid<br><span>(Comma Separated):-</span>   </label> <input class="heading-no" type="text" name="keyword_avoid" id="keywordavoid" placeholder="Please add here..." value="<?php echo $cslist; ?>" /> </div> <?php foreach ($checkArr as $checkArrkey => $checkArrvalue) { 
                                        $checked="";
                                        if(!empty($getcheckArray) && in_array($checkArrkey, $getcheckArray)){
                                        $checked="checked";
                                        }                       
                                        ?> <div class="formgroup1 checked-settings"> <label for="lang"> <?php echo $checkArrvalue; ?>   </label> <input class="chackbox2" type="checkbox" name="checkArr[]" <?php echo $checked; ?> value="<?php echo $checkArrkey; ?>" /> </div> <?php 
                                        } ?>
                                        </form>
                                    </div>
                                </div>
                                <!--  -->
                                </div>
                                    <div class="prompts-sec">
                                         <div class="prompts-box">
                                                <br/><div class="prompts">
                                                    <span class="text-prompts">Prompts</span>
                                                    <span class="button-right "><input type="button" class="show_prompt" value="Hide"></input></span>
                                                      <div class="prompts-options" >
                                                            <div class="options">
                                                                <textarea id="prompt_text"   value="" ></textarea>
                                                           </div>  
                                                      </div>
                                                </div>
                                               <button class="btn tab_regenerate_btn regen" prompt-regenerate ='currentpage' >Update settings or prompt</button>
                                         </div>
                                    </div>
                                    <!--ss -->
                            
                                <!--  -->
                        </div>
                </div>
        </div>
</div>
        <?php
            $getarr = get_option('ab_gpt3_content_settings'); 
            $getcheckArray = isset($getarr['check_Arr']) ? $getarr['check_Arr'] : ''; 
             $aiengine = get_option('ab_gpt3_ai_engine_settings');
             $apikey = isset($aiengine['api_key']) ? $aiengine['api_key'] : '';
             $current_page = admin_url( "admin.php?page=".$_GET["page"] );
            $current_page_settings = '&action=settings';
            $promptsData  = get_option('ab_prompts_content');

                  
        ?>
<script>
	const myObj = {};
    jQuery(document).ready(function(){

        var apikey = <?php echo json_encode($apikey); ?>;
           
            if (apikey.length == 0){
                alert("Please add your API key within the settings page. If you don't have an OpenAI account yet, you can sign up for one here: https://beta.openai.com/signup");
                <?php 
                    $settingurl = admin_url( "admin.php?page=Settings" );    
                ?>
                window.location = <?php echo json_encode($settingurl); ?>;
               
            }
   
          var jscheckArr = <?php echo json_encode($getcheckArray); ?>;
                if (!jscheckArr.addQNA){
                    jQuery('#conclusionCont').attr('data-nextstep','9');
                    jQuery('#conclusionSkip').attr('data-nextstep','9');
                    jQuery('#metadataBack').attr('data-nextstep','7');
                }
            
               jQuery(window).load(function(){
                var dataSet = jQuery('.active_step').attr('data-step'); 
                var currentObj = jQuery('.at_temp_sec_'+dataSet).addClass('active_page');
                allSiteInputs(currentObj);
				
                 
            });
                hideShowElement();
                var toolbarOptions = [
          ['bold', 'italic', 'underline', 'strike'],   
          ['blockquote', 'code-block'],

          [{ 'header': 1 }, { 'header': 2 }],             
          [{ 'list': 'ordered'}, { 'list': ' ' }],
          [{ 'script': 'sub'}, { 'script': 'super' }],     
          [{ 'indent': '-1'}, { 'indent': '+1' }],          
          [{ 'direction': 'rtl' }],                       
          [{ 'size': ['small', false, 'large', 'huge'] }],  
          [{ 'header': [1, 2, 3, 4, 5, 6, false] }],

          [{ 'color': [] }, { 'background': [] }],          
          [{ 'font': [] }],
          [{ 'align': [] }],

          ['clean']                         
        ];
		
		
        var quill = new Quill('.editorjs', {
            modules: {
                toolbar:toolbarOptions 
            },
            placeholder: 'Compose an epic...',
            theme: 'snow'  
        });
        window.alok = quill;
        const value = '<div class="main-div3 title_class"></div>';
            const delta = alok.clipboard.convert(value)
              alok.pasteHTML('<div class="ul1"><div>');
		var quillReview = new Quill('.editorjs2', {
            modules: {
                toolbar:toolbarOptions 
            },
            placeholder: 'Compose an epic...',
            theme: 'snow'  
        });
        window.finalreview = quillReview
        const valueReview = '<div class="main-div3 title_class"></div>';
            const deltaReview = finalreview.clipboard.convert(valueReview);
            finalreview.pasteHTML('<div class="ul1"><div>');
		
		
		jQuery('.generate_more_btn').attr('disabled', true);
        jQuery('.tab_regenerate_btn').attr('disabled', true);
        
        jQuery('body').on('click', '.copy_button', function(){
            var thisVal = jQuery(this).closest('.copycontent').find('.get_checked').val();
            var copyText = thisVal.replace(thisVal.match(/(\d+)/g), '').replace('.','').trim();
            navigator.clipboard.writeText(copyText);
            jQuery(this).val('Copied');
                    setTimeout(() => {
                        jQuery('.copy_button').val('Copy');
                    }, 1000);
        });
		
        jQuery("body").on('click', '.generate_title :checkbox' , function() {
                    jQuery('.generate_title input').removeAttr('checked');
                    jQuery(this).prop('checked',true);
            });
        jQuery('#keywordback').click(function(){
                jQuery('input[name="get_checked"]:checked').prop('checked',false);
                
               var editor_content = quill.root.innerHTML ='';
        });
		
		let originalContent;
		var toc = "";
		var checkPromptOpt = "";
		let tocCreated = false;
		
		function generateTOC() {
			const article = document.querySelector('.editorjs2 .ql-editor');
			  if (!article || !(article instanceof HTMLElement)) {
				console.error("Article element not found. Please check the selector.");
				return;
			  }

			  originalContent = article.innerHTML;

			  let tocHTML = '<h2>Table of Contents</h2><ul class="toc">';
			  let currentLevel = 2;

			  const headings = article.querySelectorAll("h2, h3, h4, h5");
			  headings.forEach((heading, index) => {
				const level = parseInt(heading.tagName.slice(1));

				while (currentLevel < level) {
				  tocHTML += '<ul class="toc">';
				  currentLevel++;
				}

				while (currentLevel > level) {
				  tocHTML += '</ul>';
				  currentLevel--;
				}

				tocHTML += `<li><a href="#heading-${index}">${heading.textContent}</a></li>`;
				heading.id = `heading-${index}`;
			  });

			  // Close all opened lists
			  while (currentLevel > 2) {
				tocHTML += '</ul>';
				currentLevel--;
			  }
			  tocHTML += '</ul>';

			  // Insert the TOC string into the Quill editor's content
			  const firstH2 = article.querySelector("h2");
			  if (firstH2) {
				 const firstH2Index = finalreview.getLength() - finalreview.getText().length + finalreview.getText().indexOf(firstH2.textContent);
				 finalreview.clipboard.dangerouslyPasteHTML(firstH2Index, tocHTML);
			  } else {
				console.error("First H2 element not found. Please check the content.");
			  }
		}

		
		function removeStartEnd(input) {
		  const wordsToRemove = ["start-output", "end-output"];

		  // Remove quotes from the input string
		  const cleanedInput = input.replace(/"/g, '');

		  // Split the input into words using commas and whitespace
		  const words = cleanedInput.split(/,\s*/);

		  // Filter out the words to remove
		  const filteredWords = words.filter(word => {
			const lowerCaseWord = word.toLowerCase().trim();
			return !wordsToRemove.includes(lowerCaseWord);
		  });
		  // Rejoin the filtered words and add quotes back
		  return filteredWords.map(word => `"${word}"`).join(", ");
		}

		
        function allSiteInputs(currentObj) {
			var getAllCheckElement = allCheckElements();
			var tab_val = currentObj
				.closest(".maincontent")
				.find(".action_val_field")
				.val();
			var titleVal = tab_val != null ? '"' + tab_val + '"' : " ";
			titleVal = titleVal.replace(/^([\d\W]\.\s*)/, '');

			var qnaStr = getAllCheckElement.qna.join(",").replace(/,/g, "").split();
			var conclusionStr = getAllCheckElement.conclusion
				.join(",")
				.replace(/,/g, "")
				.split();
			var keyVal = getAllCheckElement.keyword
				.join('", "')
				.replace(/[^\w\s,.]/gi, "");

			var tagLineVal = '"' + getAllCheckElement.tagline.join('", "') + '"';

			var headingSel = getAllCheckElement.heading.join('", "');

			var introSel = getAllCheckElement.intro.join('", "');
			var dataStep = "";

			var checkArr = jQuery("input[name='checkArr[]']")
				.map(function () {
					return jQuery(this).val();
				})
				.get();
			var allinput = jQuery("form").serializeArray();
			var aboveBelowObj = jQuery(".above_below:checked").val();
			var skipbtn = currentObj.attr("skip-btn");
			if (skipbtn == "skip") {
				dataStep = currentObj.attr("data-nextstep");
			} else {
				dataStep = jQuery(".temp-progress-bar .active_step").attr("data-step");
			}

			var promptsData = <?php echo json_encode($promptsData); ?>;

			var aiengine = <?php echo json_encode($aiengine); ?>;

			var getcheckArray = <?php echo json_encode($getcheckArray); ?>;
			var autogenerateObj = "";

			if (dataStep == 1) {
				autogenerateObj = promptsData.title_prompts;
				if (
					aiengine.model == "gpt-3.5-turbo" ||
					aiengine.model == "gpt-3.5-turbo-0301" ||
					aiengine.model == "gpt-4"
				) {
					autogenerateObj = autogenerateObj.replaceAll(
						" using a [Style] writing style and a [Tone] writing tone",
						""
					);
				}
				if (aiengine.model == "text-davinci-003" ) {
					autogenerateObj = autogenerateObj + " The current year is " +  new Date().getFullYear() + ". ";	   	   
				}
				jQuery(".checked-settings input:checked").each(function () {
				checkPromptOpt = jQuery(this).val();
					if (checkPromptOpt == "addinsertToc"){
						toc = jQuery(this).val();
					}
				});
				
				
			} else if (dataStep == 2) {
				if (allinput[5].value.length == 0) {
					autogenerateObj = promptsData.Keywords_prompts;
				} else {
					autogenerateObj = promptsData.Keywords_prompts;
				}
			} else if (dataStep == 3) {
				autogenerateObj = promptsData.outline_prompts;
				if (
					aiengine.model == "text-davinci-003"  || 
					aiengine.model == "gpt-4"   
				) {
					autogenerateObj = autogenerateObj.replaceAll(
						"and any relevant sub-sections",
						"and no sub-sections"
					);
				}
				if (
					aiengine.model == "gpt-3.5-turbo" ||
					aiengine.model == "gpt-3.5-turbo-0301" ||
					aiengine.model == "gpt-4"
				) {
					autogenerateObj = autogenerateObj.replaceAll(
						" using a [Style] writing style and a [Tone] writing tone",
						""
					);
				}
				if (
					aiengine.model == "gpt-3.5-turbo" ||
					aiengine.model == "gpt-3.5-turbo-0301"
				) {		
					autogenerateObj = autogenerateObj + " Add \"&nbsp;<!-- START&nbsp;OUTLINE -->\" at the beginning and \"&nbsp;<!-- END&nbsp;OUTLINE -->\" at the end responses. ";	 
				}
				
				if (
					aiengine.model == "text-davinci-003"  || 
					aiengine.model == "gpt-4"   
				) {
					autogenerateObj = autogenerateObj + " This needs to be for an article of no longer than 800 words."  	   
				}
			} else if (dataStep == 4) {
				autogenerateObj = promptsData.intro_prompts;

				if (
					aiengine.model == "gpt-3.5-turbo" ||
					aiengine.model == "gpt-3.5-turbo-0301" ||
					aiengine.model == "gpt-4"
				) {
					autogenerateObj = autogenerateObj.replaceAll(
						" using a [Style] writing style and a [Tone] writing tone",
						""
					);
					
				}
			} else if (dataStep == 5) {
				autogenerateObj = promptsData.tagline_prompts;

				if (
					aiengine.model == "gpt-3.5-turbo" ||
					aiengine.model == "gpt-3.5-turbo-0301" ||
					aiengine.model == "gpt-4"
				) {
					autogenerateObj = autogenerateObj.replaceAll(
						" using a [Style] writing style and a [Tone] writing tone",
						""
					);
				} 
				
			} else if (dataStep == 6) {
				autogenerateObj = promptsData.article_prompts;

				if (skipbtn == "skip" && dataStep == 6) {
					autogenerateObj = autogenerateObj.replaceAll(
						"Add a tagline called",
						""
					);
					autogenerateObj = autogenerateObj.replaceAll("[above/below].", "");
					autogenerateObj = autogenerateObj.replaceAll("[The Tagline]", "");
				}
				if (aiengine.model == "text-davinci-003" || aiengine.model == "gpt-4") {
					autogenerateObj = autogenerateObj + " Write the article with a maximum of 600 words. ";	   	   
				}
				if (aiengine.model == "gpt-3.5-turbo" || aiengine.model == "gpt-3.5-turbo-0301") {
					autogenerateObj = autogenerateObj + " Add \"&nbsp;<!--START&nbsp;ARTICLE-->\" at the beginning and \"<!--END&nbsp;ARTICLE-->\" at the end responses. ";	 
				}
			} else if (dataStep == 7) {
				autogenerateObj = promptsData.conclusion_prompts;

				if (
					aiengine.model == "gpt-3.5-turbo" ||
					aiengine.model == "gpt-3.5-turbo-0301" ||
					aiengine.model == "gpt-4"
				) {
					autogenerateObj = autogenerateObj.replaceAll(
						" using a [Style] writing style and a [Tone] writing tone",
						""
					);
				}
			} else if (dataStep == 8) {
				autogenerateObj = promptsData.qa_prompts;

				if (
					aiengine.model == "gpt-3.5-turbo" ||
					aiengine.model == "gpt-3.5-turbo-0301" ||
					aiengine.model == "gpt-4"
				) {
					autogenerateObj = autogenerateObj.replaceAll(
						" using a [Style] writing style and a [Tone] writing tone",
						""
					);
				}
			} else if (dataStep == 9) {
				autogenerateObj = promptsData.meta_prompts;
				if (
					aiengine.model == "gpt-3.5-turbo" ||
					aiengine.model == "gpt-3.5-turbo-0301" ||
					aiengine.model == "gpt-4"
				) {
					autogenerateObj = autogenerateObj.replaceAll(
						" using a [Style] writing style and a [Tone] writing tone",
						""
					);
				}
			} if (dataStep == 10) {
				var articalHtml = jQuery(".ql-editor").html();
				autogenerateObj = articalHtml + conclusionStr + qnaStr + "\n\n" + promptsData.review_prompts;
			} else if (dataStep == 11) {
 				
				if (typeof originalContent != "undefined") {
				  var articalHtml = originalContent;
				  autogenerateObj = articalHtml + "\n\n" + promptsData.evaluate_prompts;
				} else {
				  var articalHtml = jQuery(".ql-editor").html();
				  autogenerateObj = articalHtml + conclusionStr + qnaStr + "\n\n" + promptsData.evaluate_prompts;
				}

				if (getcheckArray.addsubMatter) {
					autogenerateObj = autogenerateObj + "\Have any authorities on the subject matter been included in the text? If not, list people who could be added.";
				}
				if (getcheckArray.addimgCont) {
					autogenerateObj = autogenerateObj + "\nHave any IMG tags been added within the HTML? If not, list the kinds of image and video content that would complement the article, Also, give examples of suitable royalty-free sites where to find them.";
				}
				if (getcheckArray.addfurtheReading) {
					autogenerateObj = autogenerateObj + "\nHas a section for further reading been included in the text? If not, list related topics that could be added.";
				}
				if (getcheckArray.addinsertHyper) {
					autogenerateObj = autogenerateObj + "\nHave any A tags been added within the HTML? If not, list relevant phrases within the article where hyperlinks could be added? Suggest potential domains for these hyperlinks.";
				}
				if (getcheckArray.addkeywordBold) {
					autogenerateObj = autogenerateObj + "\nHave any STRONG tags been added within the HTML? If not, list important phrases within the article where bold tags could be added";
				}
				if (checkPromptOpt == "addkeywordBold") {
					autogenerateObj = autogenerateObj + "\nHave any STRONG tags been added within the HTML? If not, list important phrases within the article where bold tags could be added";
				}
			} 
			
			var langVal = jQuery("#lang").val();
			var styleVal = jQuery("#writingStyle").val();
			var toneVal = jQuery("#writingTone").val();
			autogenerateObj = autogenerateObj.replaceAll("[Language]", langVal);
			autogenerateObj = autogenerateObj.replaceAll("[Style]", styleVal);
			autogenerateObj = autogenerateObj.replaceAll("[Tone]", toneVal);
			autogenerateObj = autogenerateObj.replaceAll("[Heading]", headingSel);
			autogenerateObj = autogenerateObj.replaceAll("[Intro]", introSel);

			var ideaSelect = titleVal.replace(/['"]+/g, "");
			ideaSelect = ideaSelect.trim();
			if (typeof ideaSelect !== "undefined" && ideaSelect != "") {
				autogenerateObj = autogenerateObj.replaceAll("[Idea]", ideaSelect);
			}
			var titleSel = getAllCheckElement.title;

			if (typeof titleSel !== "undefined" && titleSel != "") {
				autogenerateObj = autogenerateObj.replaceAll("[Title]", titleSel);
			}

			var noHeading = allinput[3].value;
			var headingTag = allinput[4].value;
			var avoidKeyword = allinput[5].value;
			if (avoidKeyword != "") {
				if (dataStep != 11 && dataStep != 9) {
					avoidKeyword = avoidKeyword.split(",");
					var keyReplace = avoidKeyword.join('", "');
					keyReplace = '"' + keyReplace + '"';
					autogenerateObj =
						autogenerateObj +
						" Exclude the following keywords " +
						keyReplace +
						" if they have been provided. ";
						
				}
			}

			if (noHeading != "") {
				autogenerateObj = autogenerateObj.replaceAll(
					"[No. Headings]",
					noHeading
				);
			}

			if (skipbtn == "skip" && dataStep == 3) {
				autogenerateObj = autogenerateObj.replaceAll(
					"and [Selected Keywords].",
					""
				);
			}

			if (keyVal !== "") {
				var keywords = keyVal.split(",");
				for (var i = 0; i < keywords.length; i++) {
					keywords[i] = '"' + keywords[i].trim() + '"';
				}
				var selKeyword = "following SEO keywords " + keywords.join(" and ");
				autogenerateObj = autogenerateObj.replaceAll(
					"[Selected Keywords]",
					selKeyword
				);
			} else {
				autogenerateObj = autogenerateObj.replaceAll(
					"Please include the following SEO keywords [Selected Keywords] where appropriate in the headings.",
					""
				);
				autogenerateObj = autogenerateObj.replaceAll(
					"and the [Selected Keywords]",
					""
				);
				autogenerateObj = autogenerateObj.replaceAll(
					"SEO optimise the content for the [Selected Keywords].",
					""
				);
				autogenerateObj = autogenerateObj.replaceAll(
					"and optimise for the [Selected Keywords]",
					""
				);
				autogenerateObj = autogenerateObj.replaceAll("[Keywords Bold].", "");
				autogenerateObj = autogenerateObj.replaceAll(
					"and the [Selected Keywords]",
					""
				);
			}

			if (aboveBelowObj != "") {
				autogenerateObj = autogenerateObj.replaceAll(
					"[above/below]",
					aboveBelowObj
				);
			}

			if (headingTag != "") {
				autogenerateObj = autogenerateObj.replaceAll(
					"[Heading Tag]",
					headingTag
				);
			}

			if (headingSel != "") {
				autogenerateObj = ( autogenerateObj.replaceAll("[Heading]", headingSel) );
			}

			var introVal = getAllCheckElement.intro;
			if (introVal != "") {
				autogenerateObj = autogenerateObj.replaceAll("[Intro]", introVal);
			} else {
				autogenerateObj = autogenerateObj.replaceAll(
					"The following introduction should be at the top: ",
					""
				);
				autogenerateObj = autogenerateObj.replaceAll("[Intro]", "");
			}

			if (tagLineVal != "") {
				var tagLS = "add the tagline " + tagLineVal;
				if (aboveBelowObj != "") {
					tagLS += " " + aboveBelowObj;
				}
				tagLS += " the introduction in a new P tag formatted in bold";
				autogenerateObj = autogenerateObj.replaceAll("[The Tagline]", tagLS);
			}

			autogenerateObj = autogenerateObj.replaceAll("\\", "");
			myObj[dataStep] = autogenerateObj;
			
			jQuery("#prompt_text").val(autogenerateObj);
			jQuery("#prompt_text").each(function(){
		});

			return autogenerateObj;
		}

		jQuery(".action_val_field").on("input", function () {
			var currentObj = jQuery(this);
			allSiteInputs(currentObj);
		});
		jQuery(".action_val_field").on("textarea", function () {
			var currentObj = jQuery(this);
			allSiteInputs(currentObj);
		});
		jQuery(".lang-additional-heading").on("change", function () {
			jQuery("#tab_input").trigger("input");
		});
		jQuery(".heading_key_avoid").on("input", function () {
			jQuery("#tab_input").trigger("input");
		});

		jQuery(".next_step_btn").click(function () {
			var getAllCheckElement = allCheckElements();
			var currentObj = jQuery(this);
			jQuery("textarea#prompt_text").val();
			jQuery(".action_val_field").val();
			var nextStep = jQuery(this).attr("data-nextstep");
			var backbtn = jQuery(this).attr("back-btn");
			var skipbtn = jQuery(this).attr("skip-btn");
			var autogenerate = jQuery(this).attr("auto-generate");
			var articalType = jQuery(this)
				.closest(".maincontent")
				.find(".tab_generate_btn")
				.attr("data-action");
			var generateObj = jQuery(this)
				.closest(".maincontent")
				.find(".after_generate_data");
			var checkboxCls = jQuery(this)
				.closest(".maincontent")
				.find(".get_checked:checked");
			var dataStep = jQuery(".temp-progress-bar .active_step").attr("data-step");

			var articalVal = currentObj
				.closest(".maincontent")
				.find(".action_val_field")
				.val();
			var currentClass = jQuery(
				`#step${jQuery(".active_step").attr("data-step")}`
			);
			if (backbtn) {
				jQuery("textarea#prompt_text").val(myObj[nextStep]);
				dataS = jQuery(".active_step").attr("data-step");
				if (dataStep !== "11") {
					jQuery(".prompts-sec").show();
				}
				rem = dataS - 1;
				var remCheck = jQuery(`[data-step='${rem}'] .rightCheck`).replaceWith(
					"<i class='fa-solid fa-square-check fa-2xl'></i>"
				);
			} else if (skipbtn == "skip") {
				allSiteInputs(currentObj);
				jQuery(".at_temp_sec_" + nextStep).addClass("active-skip");
				var closestObj = jQuery(this)
					.closest(".maincontent")
					.find(".checked-element");
				var getelemetnt = closestObj.html();
				var getAllCheckElement = allCheckElements();
				var editor_content = quill.root.innerHTML;
				var qnaStr = getAllCheckElement.qna.join(",").replace(/,/g, "").split();
				var conclusionStr = getAllCheckElement.conclusion
					.join(",")
					.replace(/,/g, "")
					.split();
				var conclusionVal =
					conclusionStr.length > 0 ? conclusionStr + "<br/><br/>" : "";
				var qnaVal = qnaStr.length > 0 ? qnaStr + "<br/><br/>" : "";
				var checkedString = editor_content + conclusionVal + qnaVal;
				if (dataStep !== "9") {
					autoGenerateElement(currentObj);
					//alert("skip not 9");
				}
				if (dataStep == 9) {
					var delta = finalreview.clipboard.convert(checkedString);
					finalreview.setContents(delta, "silent");

					if (toc == "addinsertToc") {
						setTimeout(() => {
							generateTOC(); // Call the generateTOC function after a short delay
						}, 500);
					} else {
					}
	
					
				} else {
					jQuery(".active-skip").find(".checked-element").html(getelemetnt);
				}
				jQuery(".at_temp_sec").removeClass("active-skip");
			}
			if (backbtn || skipbtn) {
				jQuery(".at_temp_sec").hide();
				var clsNext = ".at_temp_sec_" + nextStep;
				jQuery(".temp-progress-bar .step").removeClass("active_step");
				jQuery(".at_temp_sec").removeClass("active_page");
				jQuery('.temp-progress-bar div[data-step="' + nextStep + '"]').addClass(
					"active_step"
				);
				jQuery(".at_temp_sec_" + nextStep).addClass("active_page");
				jQuery(clsNext).show();
				hideShowElement();
				jQuery("html, body").animate({
					scrollTop: jQuery(".create_template_cont_sec").position().top,
				});
				return false;
			}
			if (!backbtn) {
				if (generateObj.length != 0 || nextStep === "7" || nextStep === "11") {
					if (
						checkboxCls.length != 0 ||
						nextStep === "7" ||
						nextStep === "11"
					) {
						jQuery(".progress-bar .active_step .bullet").replaceWith(
							"<i class='fa-solid fa-square-check fa-2xl'></i>"
						);
						jQuery(".at_temp_sec").hide();
						var clsNext = ".at_temp_sec_" + nextStep;
						jQuery(".temp-progress-bar .step").removeClass("active_step");
						jQuery(".at_temp_sec").removeClass("active_page");
						jQuery(
							'.temp-progress-bar div[data-step="' + nextStep + '"]'
						).addClass("active_step");
						jQuery(".at_temp_sec_" + nextStep).addClass("active_page");
						jQuery(clsNext).show();
						hideShowElement();
						jQuery("html, body").animate({
							scrollTop: jQuery(".create_template_cont_sec").position()
								.top,
						});
						var currentObj = jQuery(this);
						if (dataStep !== "9") {
							autoGenerateElement(currentObj);
						}

						checkedElement();

						var tab_val = currentObj
							.closest(".maincontent")
							.find(".action_val_field")
							.val();
						var dataStep = jQuery(".temp-progress-bar .active_step").attr(
							"data-step"
						);
						allSiteInputs(currentObj);
						setTimeout(() => {
							var currentObj = jQuery(".at_temp_sec_" + nextStep);
						}, 100);
					} else {
						alert("Please select a checkbox before continuing");
						allSiteInputs(currentObj);
					}
				} else {
					alert("Please select a " + articalType + " before continuing.");
					allSiteInputs(currentObj);
				}
			}

			if (dataStep == "10") {
					if (toc == "addinsertToc") {
						setTimeout(() => {
							generateTOC(); // Call the generateTOC function after a short delay
						}, 500);
					} else {
					}
				
			}
		});

		
			function decodeHtmlEntities(encodedString) {
			  const textArea = document.createElement("textarea");
			  textArea.innerHTML = encodedString;
			  return textArea.value;
			}
			
		
        function autoGenerateElement(currentObj){
            var getAllCheckElement = allCheckElements();
            var dataStep = jQuery(".temp-progress-bar .active_step").attr('data-step'); 
            var allinputs = jQuery("#prompt_text").val();
            var autogenerate = currentObj.attr('auto-generate');
            var generateMore = currentObj.attr('generate-more');
            var promptRegenerate = currentObj.attr("prompt-regenerate");
             var articalType = jQuery('.at_temp_sec.active_page').find('.tab_generate_btn').attr("data-action");
             var skipbtn = currentObj.attr('skip-btn');
            var linkaction = "<?php echo admin_url('admin-ajax.php')?>";
            if (autogenerate == 'cont_next_step'){
                allinputs = allSiteInputs(currentObj);
            }
            if (skipbtn == 'skip'){
             articalType = jQuery('.at_temp_sec.active-skip').find('.tab_generate_btn').attr("data-action"); 
            }
            var lang_heading_contArr = jQuery("form").serializeArray(); 
             var inputIdea = jQuery('#tab_input').val();
             var getAllCheckElement = allCheckElements();
             var title = getAllCheckElement.title != null ? getAllCheckElement.title : '';
             
             var keyVal =  getAllCheckElement.keyword.join(','); 
             var tagline =  getAllCheckElement.tagline.join(','); 
             var aboveBelowObj = jQuery(".above_below:checked").val();
             
            jQuery.ajax({
                type : "post",
                url:linkaction,
                dataType:'json',
                data : {
                     action : 'al_scribe_suggest_content',
                     autogenerateValue : allinputs,
                     actionInput : articalType,
                     idea : inputIdea,
                     title : title,
                     keyword : keyVal,
                     tagline : tagline,
                     aboveBelow : aboveBelowObj,
                     language : lang_heading_contArr[0].value,
                     writingStyle : lang_heading_contArr[1].value,
                     writingTone : lang_heading_contArr[2].value,
                     noHeading : lang_heading_contArr[3].value,
                     headingTag : lang_heading_contArr[4].value,
                     keywordToAvoid : lang_heading_contArr[5].value,
                     
                },
                 beforeSend: function(){ 
                     if (articalType == 'article' || articalType == 'evaluate'){
                            jQuery('.progress-container').css('display','block');
                            jQuery(".article-main").addClass("article_progress");
						 progress();
						 resetProgressBar();
                        }else{
                                 
                            jQuery(".article-main").addClass("overlay");
                        }
                        jQuery('button').attr('disabled', true); 
                 },
                success: function(response) {
					if (response.type == 'error') {
						// Display the error message in a popup or another UI element
						alert(response.message);
						return false;
					} else {
						// Your existing success code
						if (promptRegenerate == 'currentpage' || dataStep == 6) {
							var delta = alok.clipboard.convert(decodeHtmlEntities(response.html));
							alok.setContents(delta, 'silent')
						} else if (skipbtn && dataStep == 5) {
							var delta = alok.clipboard.convert(decodeHtmlEntities(response.html));
							alok.setContents(delta, 'silent');
						} else if (promptRegenerate == 'currentpage' || dataStep == 10) {
							var delta = finalreview.clipboard.convert(decodeHtmlEntities(response.html));
							finalreview.setContents(delta, 'silent')
						} else if (generateMore == 'generate_more') {
							jQuery('.at_temp_sec.active_page .title_class').append(response.html);
						} else {
							jQuery('.at_temp_sec.active_page .title_class').html(decodeHtmlEntities(response.html));
						}
						jQuery(".prompts-options").show();
					}
				},
                complete: function(data){
					if (articalType == 'article' || articalType == 'evaluate'){
                        jQuery('.progress-container').css('display','none');
                        jQuery(".article-main").removeClass("article_progress");
                    }else{
                            
                        jQuery(".article-main").removeClass("overlay");
                    } 
                  setTimeout(() => {
                        jQuery("button").removeAttr("disabled");
                    }, 2000);
                }

            }); 
			
        }
         
        jQuery('.tab_generate_btn').click(function(){
            var articalVal = jQuery(this).closest('.title_div').find('.action_val_field').val();
            if(articalVal == ''){
                alert('Please enter a value before clicking the continue button');
                return;
            }
            var currentObj = jQuery(this);
            autoGenerateElement(currentObj);
            jQuery('.generate_more_btn').removeAttr('disabled');
            jQuery('.tab_regenerate_btn').removeAttr('disabled');
            
        });
        jQuery('.tab_regenerate_btn').click(function(){
            var currentObj = jQuery(`#step${jQuery('.active_step').attr("data-step")}`);
            var dataStep = jQuery(".temp-progress-bar .active_step").attr('data-step');
            var articalVal = currentObj.find('.action_val_field').val();
            if(articalVal == '' && dataStep == 1){
                alert('Please Enter Input');
                return;
            }
            autoGenerateElement(currentObj);
            return false;  
        });
        jQuery('.generate_more_btn').click(function(){
            var currentObj = jQuery(this);
            var dataStep = jQuery(".temp-progress-bar .active_step").attr('data-step');
             var articalVal = currentObj.closest('.maincontent').find('.action_val_field').val();
            if(articalVal == '' && dataStep == 1){
                alert('Please Enter Input');
                return;
            }
            autoGenerateElement(currentObj);
            return false;
        });
        function allCheckElements(){
             var titleCheckObj = jQuery(".generate_title :checked").val();
             var titleCheckObj = titleCheckObj;
            var headingCheckObj = [];
            jQuery('.generate_heading .get_checked:checked').each(function(i){
              headingCheckObj[i] = jQuery(this).val();
              headingCheckObj[i] = headingCheckObj[i]?.replace(headingCheckObj[i]?.match(/(\d+)./g), '').trim();
				headingCheckObj[i] = headingCheckObj[i]?.split(/<\/?br\s*\/?>/).filter(Boolean).map(substring => `"${substring.trim()}"`).join(', ');
            });
            var keywordCheckObj = [];
            jQuery('.generate_keyword .get_checked:checked').each(function(i){
              keywordCheckObj[i] = jQuery(this).val(); 
              keywordCheckObj[i] = keywordCheckObj[i]?.replace(keywordCheckObj[i]?.match(/(\d+)./g), '').trim();
            });
            var introCheckObj = [];
            jQuery('.generate_intro .get_checked:checked').each(function(i){
              introCheckObj[i] = jQuery(this).val();
              introCheckObj[i] = introCheckObj[i]?.replace(introCheckObj[i]?.match(/(\d+)./g), '').trim();
            });
            var taglineCheckObj = [];
            jQuery('.generate_tagline .get_checked:checked').each(function(i){
              taglineCheckObj[i] = jQuery(this).val();
              taglineCheckObj[i] = taglineCheckObj[i]?.replace(taglineCheckObj[i]?.match(/(\d+)./g), '').trim();
            });
            var conclusionCheckObj = [];
            jQuery('.generate_conclusion .get_checked:checked').each(function(i){
              conclusionCheckObj[i] = jQuery(this).val();
              conclusionCheckObj[i] = conclusionCheckObj[i]?.replace(conclusionCheckObj[i]?.match(/(\d+)./g), '').trim();
            });
            var qnaCheckObj = [];
            jQuery('.generate_qna .get_checked:checked').each(function(i){
              qnaCheckObj[i] = jQuery(this).val();

              qnaCheckObj[i] = qnaCheckObj[i]?.replace(qnaCheckObj[i]?.match(/(\d+)./g), '').trim();
            }); 
            var metadataCheckObj = [];
            jQuery('.generate_seo-meta-data .get_checked:checked').each(function(i){
              metadataCheckObj[i] = jQuery(this).val();
              metadataCheckObj[i] = metadataCheckObj[i]?.replace(metadataCheckObj[i]?.match(/(\d+)./g), '').trim();
            });
                
            var allcheckArray = {
                title : titleCheckObj,
                heading : headingCheckObj, 
                keyword : keywordCheckObj,
                intro : introCheckObj,
                tagline : taglineCheckObj,
                conclusion:conclusionCheckObj,
                qna:qnaCheckObj,
                metadata:metadataCheckObj,
            };
            return allcheckArray;
        }

        jQuery('.save_post_tab').click(function(){
            var getAllCheckElement = allCheckElements();
            var linkaction = "<?php echo admin_url('admin-ajax.php')?>";
            var checkObj = jQuery(".checked_value").val();
            var editor_content = quillReview.root.innerHTML;
            jQuery.ajax({
                type: "post",
                url:linkaction,
                dataType:'json',
                data : {
                     action : 'al_scribe_send_post_page',
                    titleData : getAllCheckElement.title,
                    headingData : getAllCheckElement.heading,
                    keywordData : getAllCheckElement.keyword,
                    introData : getAllCheckElement.intro,
                    taglineData : getAllCheckElement.tagline,
                    articalVal : editor_content,
                    conclusionData : getAllCheckElement.conclusion,
                    qnaData : getAllCheckElement.qna,
                    metaData : getAllCheckElement.metadata,
                    contentData : checkObj,
                },
                beforeSend: function(){
                jQuery(".article-main").addClass("overlay"); 
            }, 
            success: function(response){
                console.log(response);
            },
             complete: function(data){
            jQuery(".article-main").removeClass("overlay");
            }
            
        }); 

    });

    jQuery('.save_as_shortcode').click(function(){
             var linkaction = "<?php echo admin_url('admin-ajax.php')?>";
             var getAllCheckElement = allCheckElements();
                 var editor_content = quillReview.root.innerHTML;
               jQuery.ajax({
                type: "post",
                dataType:'json',
                url:linkaction,
                data : {
                     action : 'al_scribe_send_shortcode_page',
                     titleData : getAllCheckElement.title,
                    headingData : getAllCheckElement.heading,
                    keywordData : getAllCheckElement.keyword,
                    introData : getAllCheckElement.intro,
                    taglineData : getAllCheckElement.tagline,
                    articalVal : editor_content,
                    conclusionData : getAllCheckElement.conclusion,
                    qnaData : getAllCheckElement.qna,
                    metaData : getAllCheckElement.metadata,
                    
                },
                 beforeSend: function(){
                    jQuery(".article-main").addClass("overlay"); 
                }, 
                success: function(response)
                {   
                  if (200 == response.status) {
                 alert("Shortcode Create Successfully");
                 }
                },
                complete: function(data){
                jQuery(".article-main").removeClass("overlay");
                }
            }); 
    });
        jQuery(".languages_style_tab").click(function(){
            var currentObj = jQuery(this);
            jQuery(".languages_style").toggle();
                currentObj.toggleClass("expanded");
                if (currentObj.hasClass("expanded")) {
                  currentObj.html("-");
                } else {
                  currentObj.html("+");
                }
        });

        jQuery(".heading_tab").click(function(){
             var currentObj = jQuery(this);
            jQuery(".hide_headings_tab").toggle();
            currentObj.toggleClass("expanded");
                if (currentObj.hasClass("expanded")) {
                  currentObj.html("-");
                } else {
                  currentObj.html("+");
                }
        });

        jQuery(".additional_content_tab").click(function(){
            var currentObj = jQuery(this);
            jQuery(".hide_addition_content").toggle();
            currentObj.toggleClass("expanded");
            if (currentObj.hasClass("expanded")) {
              currentObj.html("-");
            } else {
              currentObj.html("+");
            }
        });

        jQuery(".show_prompt").click(function(){
            jQuery(".prompts-options").toggle();
            jQuery('.regen').toggle();
            jQuery(this).val( jQuery(this).val() == 'Show' ? 'Hide' : 'Show' );
        });

        function checkedElement(){
			//alert("checkedElement");
             var getAllCheckElement = allCheckElements();
              var editor_content = quill.root.innerHTML;
              var content = jQuery('.editorjs').innerHTML;  
		
              var qnaStr = getAllCheckElement.qna.join(',').replace(/,/g, '').split();
               var conclusionStr = getAllCheckElement.conclusion.join(',').replace(/,/g, '').split();
              var dataStep = jQuery(`#step${jQuery('.active_step').attr("data-step")}`);
            var dataStepBar = jQuery(".temp-progress-bar .active_step").attr('data-step');
            var keyVal = getAllCheckElement.keyword.join('<br/>');
            var titleVal = getAllCheckElement.title.length > 0 ? ("<b> Title </b>  :- "+getAllCheckElement.title+"<br/><br/>") : '';
             var keywordVal = getAllCheckElement.keyword.length > 0 ? ("<b> Keyword </b> :- "+keyVal+"<br/><br/>") : '';
             var headingVal = getAllCheckElement.heading.length > 0 ? ("<b> Heading </b> :- "+getAllCheckElement.heading+"<br/><br/>") : '';
             var introVal =  getAllCheckElement.intro.length > 0 ? ("<b> Intro </b> :- "+getAllCheckElement.intro+"<br/><br/>") : '';
             var taglineVal = getAllCheckElement.tagline.length > 0 ? ("<b> Tagline </b> :- "+getAllCheckElement.tagline+"<br/><br/>") : '';
             var conclusionVal = conclusionStr.length > 0 ? (conclusionStr+"<br/><br/>") : '';
             var qnaVal = qnaStr.length > 0 ? (qnaStr+"<br/><br/>") : '';
             var metadataVal = getAllCheckElement.metadata.length > 0 ? ("<b> Meta Data </b>:- "+getAllCheckElement.metadata) : '';
             var aboveBelowObj = jQuery(".above_below:checked").val(); 
             var aboveBelowReviewObj = jQuery(".above_below_conclusion:checked").val();
             var checkedString = titleVal+keywordVal+headingVal+introVal+taglineVal+editor_content+conclusionVal+qnaVal+metadataVal;
              if(dataStepBar == 10){
 
				checkedString = editor_content+conclusionVal+qnaVal;

				if(aboveBelowReviewObj == 'above' || aboveBelowObj == 'above'){
 					// Combine All Output on Final Article Screen
                	checkedString = editor_content+qnaVal+conclusionVal;
            	}else{
					// Combine All Output on Final Article Screen
                    checkedString = editor_content+conclusionVal+qnaVal;
				}  
             }
             var closestObj = dataStep.find('.checked-element');
             if (dataStepBar == 10){
                var delta =  finalreview.clipboard.convert(checkedString);
                finalreview.setContents(delta, 'silent');
				}
			
			  // Create a new unordered list element
			  var ulElement = document.createElement('ul');

			  // Append the list item to the unordered list element
			  ulElement.innerHTML = '<li style="margin-bottom: 6px; margin-top: 6px; margin-left: 3px;">' + checkedString + '</li>';

			  // Append the unordered list element to the closestObj
			  var closestObj = dataStep.find('.checked-element');
			  closestObj.html(ulElement);
			
             var allcheckelement = closestObj.html('<ul><li style=" margin-bottom: 6px;  margin-top: 6px; margin-left: 3px;">'+checkedString+'</li></ul>');
             return allcheckelement;
        }

        function hideShowElement(){
            var dataStep = jQuery('.active_step').attr('data-step');
            var clsNext =  '.at_temp_sec_'+dataStep;
            var lang_heading_contArr = jQuery('.lang-additional-heading');
            if (dataStep == 10){
                jQuery("input[name='checkArr[]']").removeClass('inactive_field');
            }else{
                jQuery("input[name='checkArr[]']").addClass('inactive_field');
            }
            if (dataStep == 1 || dataStep == 2 || dataStep == 5 || dataStep == 6 || dataStep == 9 ){
                 jQuery("input[name='num_heading']").addClass('inactive_field');
                 jQuery("#heading-tag").addClass('inactive_field');
            }else{
                 jQuery("input[name='num_heading']").removeClass('inactive_field');
                 jQuery("#heading-tag").removeClass('inactive_field');
            }

            if (dataStep == 1 || dataStep == 10){
                 jQuery(".languages").removeClass('inactive_field');
             }else{
                 jQuery(".languages").addClass('inactive_field');
             }

             if (dataStep == 4 || dataStep == 7){
                 jQuery(".no_heading").addClass('inactive_field');
             }else{
                 jQuery(".no_heading").removeClass('inactive_field');
             }

             if (dataStep == 6 || dataStep == 11){
                jQuery(".form1").addClass('inactive_field');

            }else{
                jQuery(".form1").removeClass('inactive_field');
            }
        } 


		var i = 0;
		function progress() {
		  if (i == 0) {
			i = 1;
			var elem = document.getElementById("progressBar");
			var width = 10;
			var id = setInterval(frame, 400);
			function frame() {
			  if (width >= 100) {
				clearInterval(id);
				i = 0;
				elem.innerHTML = "WAIT (STILL LOADING)...";
				elem.style.animation = "buzzing 0.2s linear infinite";
			  } else {
				width++;
				elem.style.width = width + "%";
				elem.innerHTML = width  + "%";
			  }
			}
		  }
		}
		
		function resetProgressBar() {
		  var elem = document.getElementById("progressBar");
		  elem.style.width = "0%";
		  elem.innerHTML = "0%";
		  elem.style.animation = "none";
		}
});  

</script>

