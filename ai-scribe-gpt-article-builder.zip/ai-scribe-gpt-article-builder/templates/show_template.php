<html>
  <head>
    <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>AI-Scribe Shortcodes: ChatGPT SEO Content Creator</title>
	  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	  <style>
	   th, td {
    		text-align: center !important;
		}
		h4 {
    		margin-top: 3px; 
			margin-bottom: 3px; 
		}
	  </style>
	</head>
<body>
<h1>
	Saved Shortcodes
</h1>
<table class="widefat fixed"  cellspacing="0">
    <thead>
        <?php
 			global $wpdb;
            $table_name = $wpdb->prefix . 'article_builder';
            $post_data = $wpdb->get_results("SELECT id,title,heading from $table_name ORDER BY id DESC ");
                
            $current_page = admin_url( "admin.php?page=".$_GET["page"] );
            $current_page_edit = '&action=edit&id=';
            $current_page_delete = '&action=delete&id=';
             if (!$post_data == null) {
                ?>
    	<tr>
            <th id="columnname" class="manage-column column-cb check-column" scope="col"><h4>Title</h4></th>
            <th id="columnname" class="manage-column column-cb check-column" scope="col"><h4>Shortcode</h4></th> 
            <th id="columnname" class="manage-column column-cb check-column" scope="col"><h4>Action</h4></th> 
   		 </tr>
    </thead>
    <tbody>
            <?php 
            foreach ($post_data as $key=> $value) {
             ?>               
        <tr class="alternate">
            <td class="column-columnname"><?= $value->title; ?></td>
            <td class="column-columnname">[article_builder_generate_data template_id="<?= $value->id; ?>"]</td>
           	<!-- <td class="column-columnname"><a href="<?php echo $current_page.$current_page_edit.$value->id; ?>"><button class="btn btn-primary" style="margin-right: 10px;">Edit </button></a> -->
                <td>
                 <button class="btn btn-danger delete" data-id = <?php echo $value->id; ?>>Remove</button>
                 <img src="<?php echo plugins_url('article_builder/assets/loder.gif');?>" img-id = <?php echo $value->id; ?> id="loader-img" style="display:none; width:20px;" / >
                   </td>  
        </tr>
         <?php
             }
             }else{
                /* update 24.03.23 */
                 echo "<br/><br/>No shortcodes have been saved.";

          }
           
          ?>
    </tbody>
</table>  
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
 <script >
 $(document).ready(function() {
    $(".delete").click(function(e){
        e.preventDefault();
        
        var id = jQuery(this).attr('data-id');
        var imgId = jQuery("#loader-img").attr('img-id'); 
         jQuery(imgId).show();
        var link = "<?php echo admin_url('admin-ajax.php')?>";
         var x = confirm("Are you sure you want to delete?");
         if(x){
        jQuery.ajax({
            type: "post",
            url:link,
            data : {
                action : 'al_scribe_remove_short_code_content',
                id : id
            },
            success: function(response)
            {
                jQuery(imgId).hide();
               location.reload();     
           },
       });
     }
  });
});
 </script>
</body>