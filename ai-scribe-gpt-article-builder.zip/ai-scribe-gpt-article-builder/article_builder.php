<?php
/*
 * Contributors: 		OPACE LTD, MITASH TEAM
 * Plugin Name: 		AI-Scribe: The ChatGPT-Powered SEO Content Creation Wizard
 * Description: 		AI-Scribe from Opace is a keyword-driven article Generator using GPT-3, GPT-3.5 or GPT-4 using OpenAI. Perfect for creating blog posts and articles using AI.
 * Plugin URI: 			https://www.opace.co.uk/ai-scribe
 * Text Domain: 		ai-scribe-gpt-article-builder
 * Tags: 				AI, GPT, SEO, Content Creator, Article Builder, Article Generator, OpenAI, GPT-3, GPT-4, GPT-3.5, GPT-3.5-Turbo, Text Creator, Blog Creator
 * Author URI: 			https://www.opace.co.uk
 * Author: 				OPACE
 * Requires at least: 	4.4 or higher
 * Tested up to: 		6.1.1
 * Stable tag:  		OPACE LTD
 * Version: 			1.1
 * Author URI: 			https://www.opace.co.uk/
 * License:          	GPL-3.0
 * License URI:      	http://www.gnu.org/licenses/gpl-3.0.txt
 * Domain Path:      	/languages
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

class AI_Scribe
{
    public function __construct()
    {
        register_activation_hook(__FILE__, [$this, 'activate']);
        register_deactivation_hook(__FILE__, [$this, 'deactivate']);
		
        add_action('admin_menu', [
            $this, 'add_menu'
        ]);
        add_action('wp_ajax_al_scribe_remove_short_code_content', [
            $this,
            'remove_short_code_content',
        ]);
        add_action('wp_ajax_al_scribe_content_data', [
            $this, 'content_data'
        ]);
        add_action('wp_ajax_al_scribe_engine_request_data', [
            $this,
            'engine_request_data',
        ]);
        add_action('wp_ajax_al_scribe_send_post_page', [
            $this,
            'send_post_page',
        ]);
		add_action('wp_ajax_al_scribe_suggest_content', [
            $this,
            'suggest_content',
        ]);
		add_action('wp_ajax_al_scribe_send_shortcode_page', [
            $this,
            'send_shortcode_page',
        ]);
		add_action('wp_ajax_get_article', [
			$this, 
			'get_article'
		]);
		add_action('admin_post_ai_scribe_delete_data_confirm', [
			$this, 
			'ai_scribe_delete_data_confirm'
		]);
		add_action('admin_notices', [
			$this, 
			'ai_scribe_uninstall_notice'
		]);
		add_action('plugins_loaded', [
			$this, 
			'load_textdomain'
		]);
		
        add_shortcode('article_builder_generate_data', [
            $this,
            'send_shortcode_page_data',
        ]);
		
		add_filter('plugin_action_links_' . plugin_basename(__FILE__), [$this, 'add_settings_link']);
    }
	/*
	* Function: get_article
	* Description: Initializes the cURL request to get the article data.
	*/
    public function get_article() 
	{
        // Initialize the cURL request
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 300, // Increase the timeout value to 300 seconds (5 minutes)
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => [
                "cache-control: no-cache"
            ],
        ]);
	}
	/*
	* Function: activate
	* Description: Creates the custom database table and sets default options when the plugin is activated.
	*/
    public function activate()
    {
		global $wpdb, $table_prefix;
        $wp_article = $table_prefix . "article_builder";
        if ($wpdb->get_var("show tables like '$wp_article'") != $wp_article) {
            $q = "CREATE TABLE `$wp_article` (
                    `id` int(20) NOT NULL AUTO_INCREMENT,
                      `title` text DEFAULT NULL,
                      `heading` text DEFAULT NULL,
                      `keyword` text DEFAULT NULL,
                      `intro` text DEFAULT NULL,
                      `tagline` text DEFAULT NULL,
                      `article` text DEFAULT NULL,
                      `conclusion` longtext DEFAULT NULL,
                      `qna` longtext DEFAULT NULL,
                      `metadata` longtext DEFAULT NULL,
                        PRIMARY KEY  (`id`)
                    )ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
            $wpdb->query($q);
        }
        $this->set_default_options();
		add_option('ai_scribe_delete_data_on_uninstall', 'no');
    }
	/*
	* Function: load_textdomain
	* Description: Loads the plugin's textdomain for translations.
	*/
	public function load_textdomain() 
	{
    	load_plugin_textdomain('article_builder', false, basename(dirname(__FILE__)) . '/languages/');
	}
	/*
	* Function: ai_scribe_uninstall_notice
	* Description: Displays a notice in the admin area asking the user if they want to delete all data when uninstalling the plugin.
	*/
	public function ai_scribe_uninstall_notice() 
	{
		$screen = get_current_screen();
		if ($screen->id == 'plugins') {
			$delete_data = get_option('ai_scribe_delete_data_on_uninstall');
			if ($delete_data === 'no') {
				?>
				<div class="notice notice-warning is-dismissible">
					<p>
						<strong>AI Scribe:</strong> Do you want to delete all data when uninstalling the plugin?
						<a href="<?php echo admin_url('admin-post.php?action=ai_scribe_delete_data_confirm&choice=yes'); ?>">Yes</a>
						|
						<a href="<?php echo admin_url('admin-post.php?action=ai_scribe_delete_data_confirm&choice=no'); ?>">No</a>
					</p>
				</div>
				<?php
			}
		}
	}
	/*
	* Function: ai_scribe_delete_data_confirm
	* Description: Updates the option to delete or not delete data on plugin uninstall based on user's choice.
	*/
	public function ai_scribe_delete_data_confirm() 
	{
		if (isset($_GET['choice'])) {
			update_option('ai_scribe_delete_data_on_uninstall', $_GET['choice']);
		}
		wp_redirect(admin_url('plugins.php'));
		exit;
	}
	/*
	* Function: uninstall
	* Description: Removes custom database tables and options created by the plugin when it's uninstalled, if the user has chosen to delete all data.
	*/
	public function uninstall() 
	{
		$delete_data = get_option('ai_scribe_delete_data_on_uninstall');
		if ($delete_data === 'yes') {
			// Remove custom database tables
			global $wpdb;
			$table_name = $wpdb->prefix . "article_builder";
			$wpdb->query("DROP TABLE IF EXISTS $table_name");

			// Remove options created by the plugin
			delete_option('ab_gpt3_ai_engine_settings');
			delete_option('ab_gpt3_content_settings');
		}
	}
	/*
	* Function: deactivate
	* Description: Placeholder function for when the plugin is deactivated.
	*/
    public function deactivate()
    {
    }
	/*
	* Function: add_settings_link
	* Description: Adds the Settings and Help links to the plugin's action links on the plugins page.
	*/
	public function add_settings_link($links) 
	{
		$settings_link = '<a href="' . admin_url('admin.php?page=Settings') . '">' . __('Settings', 'article_builder') . '</a>';
		$about_link = '<a href="' . admin_url('admin.php?page=Help') . '">' . __('Help', 'article_builder') . '</a>';
    	array_unshift($links, $settings_link, $about_link, $help_link);
    	return $links;
	}
	/*
	* Function: set_default_options
	* Description: Sets the default options for the plugin's settings.
	*/
    private function set_default_options()
    {
        $contentsetting = [
            'language' => 'English',
            'writing_style' => 'Creative',
            'writing_tone' => 'Dramatic',
            'number_of_heading' => '5',
            'Heading_tag' => 'H2',
            'check_Arr' => [
                'addQNA' => 'addQNA',
                'addinsertHyper' => 'addinsertHyper',
                'addinsertToc' => 'addinsertToc',
                'addfurtheReading' => 'addfurtheReading',
                'addsubMatter' => 'addsubMatter',
                'addimgCont' => 'addimgCont',
				'addkeywordBold' => 'addkeywordBold',
            ],
            'cs_list' => '',
        ];
        $enginesetting = [
            'model' => 'text-davinci-003',
            'temp' => 0.5,
            'top_p' => 0.5,
            'freq_pent' => 0.2,
            'Presence_penalty' => 0.2,
            'n' => 1,
        ];
        $promptssetting = [
            'title_prompts' =>
                'Provide 5 unique article titles for my blog based on "[Idea]". They need to be unique and catchy. Write them in the [Language] language using a [Style] writing style and a [Tone] writing tone.',
            'Keywords_prompts' =>
                'For the title "[Title]", provide a list of 5 relevant keywords or phrases each on a new line. These need to be popular searches in Google and capable of driving traffic to the article. Capitsalise each word.',
			'outline_prompts'=>
                'I need an outline of my article titled "[Title]". Create [No. Headings] sections and any relevant sub-sections for the body of my article but don\'t include an introduction or conclusion. Please include the following SEO keywords [Selected Keywords] where appropriate in the headings. Write the outline in the [Language] language using a [Style] writing style and a [Tone] writing tone.',
            'intro_prompts' =>
                'Generate an introduction for my article as a single paragraph. Base the introduction on the "[Title]" title and the [Selected Keywords]. Write the introduction in the [Language] language using a [Style] writing style and a [Tone] writing tone.',
			'tagline_prompts'=>
                'Generate a tagline for my article. Base the tagline on the "[Title]" title and the [Selected Keywords]. Write the tagline in the [Language] language using a [Style] writing style and a [Tone] writing tone. Use persuasive power words.',
			'article_prompts'=>
                'Write a HTML article to include an H1 tag for the "[Title]" main title. The following introduction should be at the top: "[Intro]". Add a tagline called "[The Tagline]" [above/below]. Then write the article and include descriptive text for the following sections and sub-sections, and vary the length of each typically with 50 to 250 words: [Heading]. Each section should provide a unique perspective on the topic and provide value over and above what\'s already available. Don\'t include a conclusion. Format each section heading as a [Heading Tag] tag. SEO optimise the article for the [Selected Keywords]. Don\'t include lists. Write the article in the [Language] language using a [Style] writing style and a [Tone] writing tone.',
            'conclusion_prompts' =>
                'Create a conclusion in its own paragraph. Based this on the "[Title]" and optimise for the [Selected Keywords]. Write in the [Language] language using a [Style] writing style and a [Tone] writing tone. Include a call to action to express a sense of urgency. Within the paragraph, include a [Heading Tag] tag for the heading to contain the word "conclusion, and use a P tag for the body. Don\'t use lists or LI tags.',
            'qa_prompts' =>
                'Create [No. Headings] individual Questions and Answers, each in their own paragraph. Based these on the "[Title]" title and the [Selected Keywords]. Write in the [Language] language using a [Style] writing style and a [Tone] writing tone. Within each paragraph, include a [Heading Tag] tag for the question and a P tag for the answer. Ensure they provide additional useful information to supplement the main "[Title]" article. Don\'t use lists or LI tags.',
            'meta_prompts' =>
                'Create a single SEO friendly meta title and meta description. Based this on the "[Title]" article title and the [Selected Keywords]. Create the meta data in the [Language] language using a [Style] writing style and a [Tone] writing tone.  Follow SEO best practices and make the meta data catchy to attract clicks.',
            'review_prompts' =>
                'Please revise the above article and HTML code so that it has [No. Headings] headings using the [Heading Tag] HTML tag. Revise the text in the [Language] language. Revise with a [Style]  style and a [Tone] writing tone.',
            'evaluate_prompts' => 
			'Create a HTML table giving a strict/evaluation of each question below based on everything above. Give the HTML table 4 columns: [STATUS], [QUESTION], [EVALUATION], [RATIONALE]. For [EVALUATION], give a PASS, FAIL or IMPROVE response. Add a CSS class name to each row with the corresponding response value. For the [STATUS] column, don\'t add anything. For [RATIONALE], explain your reasoning. Order the rows according to  [EVALUATION]. All answers must be factual. Hen giving examples like phrases or topics add these within curly brackets. The questions are:
Is the length of the article over 500 words and an adequate length compared to similar articles?
Is the article optimised for certain keywords or phrases? What are these?
Is the article well-written and easy to read?
Does the article have any spelling or grammar issues?
Does the article provide an original, interesting and engaging perspective on the topic?',
        ];
        update_option('ab_gpt3_content_settings', $contentsetting);
        update_option('ab_gpt3_ai_engine_settings', $enginesetting);
        update_option('ab_prompts_content', $promptssetting);
    }
	/*
	* Function: add_menu
	* Description: Adds the plugin's menu and submenu items to the WordPress admin area.
	*/
    public function add_menu()
    {
        add_menu_page(
            'AI-Scribe',
            'AI-Scribe',
            'manage_options',
            'Help',
            [$this, 'main_page'],
            '',
            15
        );
        add_submenu_page(
            'Help',
            'Generate Article',
            'Generate Article',
            'manage_options',
            'generate_article',
            [$this, 'create_template']
        );
        add_submenu_page(
            'Help',
            'Saved Shortcodes',
            'Saved Shortcodes',
            'manage_options',
            'saved_shortcodes',
            [$this, 'all_templates']
        );
        add_submenu_page(
            'Help',
            'Settings',
            'Settings',
            'manage_options',
            'Settings',
            [$this, 'settings_page']
        );
		add_submenu_page(
            'Help',
            'Help',
            'Help',
            'manage_options',
            'Help',
            [$this, 'main_page']
        );

				?>

                <style>
                    .toplevel_page_Help li.wp-first-item {
                        display: none;
                    }
                </style>

                <?php
    }
	/*
	* Function: main_page
	* Description: Includes the main page template for the plugin.
	*/
    public function main_page()
    {
        include_once 'common/help.php';
    }
	/*
	* Function: create_template
	* Description: Includes the "Generate Article" or "Saved Shortcodes" template based on the current page.
	*/
    public function create_template()
    {
        $page = isset($_GET["page"]) ? $_GET["page"] : '';

        if ($page == 'saved_shortcodes') {
            include_once 'templates/show_template.php';
        } else {
            include_once 'templates/create_template.php';
        }
    }
	/*
	* Function: all_templates
	* Description: Includes the "Saved Shortcodes" or "Settings" template based on the current page and action.
	*/
    public function all_templates()
    {
        $page = isset($_GET["page"]) ? $_GET["page"] : '';
        $action = isset($_GET["action"]) ? $_GET["action"] : '';
        if ($page && $action == 'exit') {
            $this->create_template();
        } elseif ($page && $action == 'settings') {
            include_once 'common/settings.php';
        } else {
            include_once 'templates/show_template.php';
        }
    }
	/*
	* Function: settings_page
	* Description: Includes the "Settings" template for the plugin.
	*/
    public function settings_page()
    {
        include_once 'common/settings.php';
    }
	/*
	* Function: remove_short_code_content
	* Description: Removes a saved shortcode from the custom database table.
	*/
    public function remove_short_code_content(){      
        global $wpdb;
        $id = $_POST['id'];
        $table_name = $wpdb->prefix . 'article_builder';
        $edit_record = $wpdb->query(
            " DELETE  FROM $table_name WHERE `id`='$id'"
        );
        header('Location: admin.php?page=at_templates');
    }
	/*
	* Function: content_data
	* Description: Updates the content settings in the options table.
	*/
    public function content_data()
    {
        $lang = isset($_POST['language']) ? $_POST['language'] : '';
        $wrtStyle = isset($_POST['writing_style'])
            ? $_POST['writing_style']
            : '';
        $wrtStone = isset($_POST['writing_tone']) ? $_POST['writing_tone'] : '';
        $numHeading = isset($_POST['number_of_heading'])
            ? $_POST['number_of_heading']
            : '';
        $headTag = isset($_POST['Heading_tag']) ? $_POST['Heading_tag'] : '';
        $modHead = isset($_POST['modify_heading'])
            ? $_POST['modify_heading']
            : '';
        $checkboxArr = isset($_POST['checkArr']) ? $_POST['checkArr'] : '';
        $promptsContent = isset($_POST['prompts_content'])
            ? $_POST['prompts_content']
            : '';
        $cslist = isset($_POST['cs_list']) ? $_POST['cs_list'] : '';
        $frmArr = [
            'language' => $lang,
            'writing_style' => $wrtStyle,
            'writing_tone' => $wrtStone,
            'number_of_heading' => $numHeading,
            'Heading_tag' => $headTag,
            'modify_heading' => $modHead,
            'check_Arr' => $checkboxArr,
            'cs_list' => $cslist,
        ];
        update_option('ab_gpt3_content_settings', $frmArr);
        update_option('ab_prompts_content', $promptsContent);
        $resArr = [
            'status' => 'success',
            'msg' => 'Your settings have been updated successfully',
        ];
        echo json_encode($resArr);
        exit();
    }
	/*
	* Function: engine_request_data
	* Description: Updates the AI engine settings in the options table.
	*/
    public function engine_request_data()
    {
        $model = isset($_POST['model']) ? $_POST['model'] : '';
        $temp = isset($_POST['temp']) ? $_POST['temp'] : '';
        //$max_tokens = isset($_POST['max_tokens']) ? $_POST['max_tokens'] : '';
        $top_p = isset($_POST['top_p']) ? $_POST['top_p'] : '';
        //$best_oi = isset($_POST['best_oi']) ? $_POST['best_oi'] : '';
        $freq_pent = isset($_POST['freq_pent']) ? $_POST['freq_pent'] : '';
        $Presence_penalty = isset($_POST['Presence_penalty'])
            ? $_POST['Presence_penalty']
            : '';
        $api_key = isset($_POST['api_key']) ? $_POST['api_key'] : '';
        $frmagArr = [
            'model' => $model,
            'temp' => $temp,
            'max_tokens' => 2500,
            'top_p' => $top_p,
            //'best_oi' => $best_oi,
            'freq_pent' => $freq_pent,
            'Presence_penalty' => $Presence_penalty,
            'api_key' => $api_key,
        ];
        update_option('ab_gpt3_ai_engine_settings', $frmagArr);
        $resArr = [
            'status' => 'success',
            'msg' => 'Your settings have been updated successfully',
        ];
        echo json_encode($resArr);
        exit();
    }
	/*
	* Function: send_post_page
	* Description: Inserts a new post with the generated article content and updates its Yoast SEO meta title and description.
	*/
    public function send_post_page()
    {
        ob_start();
        $titleData = isset($_POST['titleData']) ? $_POST['titleData'] : '';
        $headingData = isset($_POST['headingData'])
            ? $_POST['headingData']
            : '';
        $headingStr = implode(" ", $headingData);
        $keywordData = isset($_POST['keywordData'])
            ? $_POST['keywordData']
            : '';
        $keywordStr = implode(" ", $keywordData);
        $introData = isset($_POST['introData']) ? $_POST['introData'] : '';
        $introStr = implode(" ", $introData);
        $taglineData = isset($_POST['taglineData'])
            ? $_POST['taglineData']
            : '';
        $taglineStr = implode(" ", $taglineData);
        $articalVal = isset($_POST['articalVal']) ? $_POST['articalVal'] : '';

        $articalValue = preg_replace("/<h1>.*<\/h1>/", " ", $articalVal);
        $conclusionData = isset($_POST['conclusionData'])
            ? $_POST['conclusionData']
            : '';
        $conclusionStr = implode(" ", $conclusionData);
        $qnaData = isset($_POST['qnaData']) ? $_POST['qnaData'] : '';
        $qnaStr = implode(" ", $qnaData);
        $metaData = isset($_POST['metaData']) ? $_POST['metaData'] : '';
        $metadataStr = implode(" ", $metaData);
        $contentData = isset($_POST['contentData'])
            ? $_POST['contentData']
            : '';
        $pattern = "/<h1>.*<\/h1>/";
        preg_match($pattern, $articalVal, $matches);
        $articalValue = preg_replace("/<br>|\n|<br( ?)\/>/", "", $articalValue);

        $my_post = [
            'post_type' => 'post',
            'post_title' => strip_tags($matches[0]),
            'post_content' => $articalValue,
            'post_status' => 'draft',
        ];
        $insertPost = wp_insert_post($my_post);
        if ($insertPost > 0) {
            update_post_meta($insertPost, '_yoast_wpseo_title', $metaData[0]);
            update_post_meta(
                $insertPost,
                '_yoast_wpseo_metadesc',
                $metaData[1]
            );
        }
        return ob_get_clean();
        exit();
    }
	/*
	* Function: send_shortcode_page
	* Description: Saves the generated article content as a shortcode in the custom database table.
	*/
    public function send_shortcode_page()
    {
        ob_start();
        $titleData = isset($_POST['titleData']) ? $_POST['titleData'] : '';
        $headingData = isset($_POST['headingData'])
            ? $_POST['headingData']
            : '';
        $headingStr = implode(" ", $headingData);
        $keywordData = isset($_POST['keywordData'])
            ? $_POST['keywordData']
            : '';
        $keywordStr = implode(" ", $keywordData);
        $introData = isset($_POST['introData']) ? $_POST['introData'] : '';
        $introStr = implode(" ", $introData);
        $taglineData = isset($_POST['taglineData'])
            ? $_POST['taglineData']
            : '';
        $taglineStr = implode(" ", $taglineData);
        $articalVal = isset($_POST['articalVal']) ? $_POST['articalVal'] : '';
        $articalValue = preg_replace("/<h1>.*<\/h1>/", " ", $articalVal);
        $articalValue = preg_replace("/<br>|\n|<br( ?)\/>/", "", $articalValue);
        $conclusionData = isset($_POST['conclusionData'])
            ? $_POST['conclusionData']
            : '';
        $conclusionStr = implode(" ", $conclusionData);
        $qnaData = isset($_POST['qnaData']) ? $_POST['qnaData'] : '';
        $qnaStr = implode(" ", $qnaData);
        $metaData = isset($_POST['metaData']) ? $_POST['metaData'] : '';
        $metaDataStr = implode(" ", $metaData);
        $pattern = "/<h1>.*<\/h1>/";
        preg_match($pattern, $articalVal, $matches);
        global $wpdb, $table_prefix;
        $wp_article = $table_prefix . "article_builder";
        $wpdb->insert($wp_article, [
                        'title' => strip_tags($matches[0]),
                        'heading' => $headingStr,
                        'keyword' => $keywordStr,
                        'intro' => $introStr,
                        'tagline' => $taglineStr,
                        'article' => $articalValue,
                        'conclusion' => $conclusionStr,
                        'qna' => $qnaStr,
                        'metadata' => $metaData,

        ]);
        return ob_get_clean();
        exit();
    }
	/*
	* Function: send_shortcode_page_data
	* This function retrieves the data associated with the given template ID and returns 
	* the combined content of the title, article, conclusion, and QnA.
	*/
	public function send_shortcode_page_data($attr)
	{
		//echo "Function called<br>"; // Add this line
		ob_start();
		$tempId = isset($attr['template_id']) ? $attr['template_id'] : "";
		global $wpdb, $table_prefix;
		$wp_article = $table_prefix . "article_builder";
		$getData = $wpdb->get_results(" SELECT * FROM $wp_article WHERE `id`='$tempId'");
		foreach ($getData as $key => $value) {
			echo '<h1>'.$value->title.'</h1>';
			echo $value->article;
			echo $value->conclusion;
			echo $value->qna;
		}
		return ob_get_clean();
	}
	/*
	 * V1.1
	 * Function: calculate_cost
	 * This function calculates the cost based on the tokens count and cost per token.
	 */
	public function calculate_cost($tokens_count, $cost_per_token) {
		return $tokens_count * $cost_per_token;
	}
	/*
	* Function: suggest_content
	* This function sends a request to the OpenAI API with the given input and settings, 
	* processes the response, and generates the output in the desired format based on the actionInput value.
	*/
    public function suggest_content()
    {       
        // Error reporting
		//ini_set('display_errors', 1);
		//ini_set('display_startup_errors', 1);
		//error_reporting(E_ALL);
		
		$autogenerateValue = isset($_POST['autogenerateValue'])
            ? $_POST['autogenerateValue']
            : '';
        $actionInput = isset($_POST['actionInput'])
            ? $_POST['actionInput']
            : '';

        $autogenerateValue = str_replace('"', "'", $autogenerateValue);

        $getarr = get_option('ab_gpt3_ai_engine_settings');

        $apikey = isset($getarr['api_key']) ? $getarr['api_key'] : '';
        $model = isset($getarr['model']) ? $getarr['model'] : '';
        $temp = isset($getarr['temp']) ? $getarr['temp'] : '';
        $top_p = isset($getarr['top_p']) ? $getarr['top_p'] : '';
        $freq_pent = isset($getarr['freq_pent']) ? $getarr['freq_pent'] : '';
        $Presence_penalty = isset($getarr['Presence_penalty'])
            ? $getarr['Presence_penalty']
            : '';
        $max_tokens = '';

        if ($actionInput == 'evaluate') {
            $max_tokens = '1500';
        } elseif ($actionInput == 'article' || $actionInput == 'review') {
            $max_tokens = '2000';
        } elseif ($actionInput == 'qna' || $actionInput == 'heading') {
            $max_tokens = '750';
        } else {
            $max_tokens = '250';
        }

        $max_tokens = intval($max_tokens);
        $temp = floatval($temp);
        $top_p = floatval($top_p);

        if ($actionInput == 'evaluate') {
            $presence_penalty = 0;
            $freq_pent = 0;
        } else {
            $presence_penalty = floatval($Presence_penalty);
            $freq_pent = floatval($freq_pent);
        }

        $curl = curl_init();

        $settings = get_option('ab_gpt3_content_settings');
        $actualStyle = isset($settings['writing_style'])
            ? $settings['writing_style']
            : '';
        $actualTone = isset($settings['writing_tone'])
            ? $settings['writing_tone']
            : '';

        if ($model == 'gpt-3.5-turbo' || $model == 'gpt-3.5-turbo-0301') {
            $messages = [
                [
                    "role" => "system",
                    "content" =>
					"You are a talented human copywriter in the year " .
                    date('Y') .
                    " following my instructions. Write in a " .
                    $actualTone .
                    " writing tone.",
                ],
                [
                    "role" => "user",
                    "content" => $autogenerateValue,
                ],
            ];
        } elseif ($model == 'gpt-4') {
            $messages = [
                [
                    "role" => "system",
                    "content" =>
                        "When writing, you are a talented human copywriter in the year " .
                        date('Y') .
                        " following my instructions. You only produce a maximum of 600 words and write in a " .
                        $actualStyle .
                        " writing style and a " .
                        $actualTone .
                        " writing tone. " .
                        "When performing SEO activities, don't apply any kind of writing style or tone. " .
                        "You are an SEO expert, strictly analytical and always follow best practice.",
                ],
                [
                    "role" => "user",
                    "content" => $autogenerateValue,
                ],
            ];
        }

        // Set up the request array
        $send_arr = [
            "model" => $model,
            "temperature" => $temp,
            "top_p" => $top_p,
            "frequency_penalty" => $freq_pent,
            "presence_penalty" => $presence_penalty,
            "n" => 1,
        ];

        $endpoint = '';
        if ($model == 'text-davinci-003' || $model == 'text-davinci') {
            $endpoint = 'v1/completions';
            $send_arr['model'] = $model;
            $send_arr['prompt'] = $autogenerateValue;
            $send_arr['max_tokens'] = $max_tokens;
            $send_arr['temperature'] = $send_arr['temperature'];
            $send_arr['top_p'] = $send_arr['top_p'];
            $send_arr['presence_penalty'] = $send_arr['presence_penalty'];
            $send_arr['frequency_penalty'] = $send_arr['frequency_penalty'];
        } elseif ($model == 'gpt-3.5-turbo') {
            $endpoint = 'v1/chat/completions';
            $send_arr['model'] = 'gpt-3.5-turbo';
            $send_arr['messages'] = $messages;
            $send_arr['temperature'] = $send_arr['temperature'] * 2;
            $send_arr['top_p'] = $send_arr['top_p'] * 2;
            //$send_arr['max_tokens'] = $max_tokens;
            $send_arr['presence_penalty'] = $send_arr['presence_penalty'] / 2;
            $send_arr['frequency_penalty'] = $send_arr['frequency_penalty'] / 2;
            $send_arr['stop'] = "\n\n\n"; // using a longer stop sequence
        } elseif ($model == 'gpt-3.5-turbo-0301') {
            $endpoint = 'v1/chat/completions';
            $send_arr['model'] = 'gpt-3.5-turbo';
            $send_arr['messages'] = $messages;
            $send_arr['temperature'] = $send_arr['temperature'] * 2;
            $send_arr['top_p'] = $send_arr['top_p'] * 2;
            //$send_arr['max_tokens'] = $max_tokens;
            $send_arr['presence_penalty'] = $send_arr['presence_penalty'] / 2;
            $send_arr['frequency_penalty'] = $send_arr['frequency_penalty'] / 2;
            $send_arr['stop'] = "\n\n\n"; // using a longer stop sequence
        } elseif ($model == 'gpt-4') {
            $endpoint = 'v1/chat/completions';
            $send_arr['model'] = 'gpt-4';
            $send_arr['messages'] = $messages;
            $send_arr['temperature'] = $send_arr['temperature'] * 1.5;
            //$send_arr['max_tokens'] = $max_tokens * 2;
            $send_arr['presence_penalty'] = $send_arr['presence_penalty'] / 2;
            $send_arr['frequency_penalty'] = $send_arr['frequency_penalty'] / 2;
            $send_arr['stop'] = "\n\n\n"; // using a longer stop sequence
        } else {
            $endpoint = 'v1/completions';
            $send_arr['model'] = $model;
            $send_arr['prompt'] = $autogenerateValue;
            $send_arr['max_tokens'] = $max_tokens;
            $send_arr['temperature'] = $send_arr['temperature'];
            $send_arr['top_p'] = $send_arr['top_p'];
            $send_arr['presence_penalty'] = $send_arr['presence_penalty'];
            $send_arr['frequency_penalty'] = $send_arr['frequency_penalty'];
        }

        $json_str = json_encode($send_arr);

        // Set up the curl request
        curl_setopt_array($curl, [
            CURLOPT_URL => 'https://api.openai.com/' . $endpoint,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $json_str,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $apikey,
                'Content-Type: application/json',
            ],
        ]);

        $response = curl_exec($curl);
		
		/* V1.1 CODE */
		// Add this line to initialize the tokens_count variable
		$tokens_count = 0;

		// Decode the JSON response into an associative array
		$response_data = json_decode($response, true);

		// Extract the tokens count from the API response
		if ($endpoint === 'v1/completions') {
			$tokens_count = $response_data['usage']['total_tokens'];
		} elseif ($endpoint === 'v1/chat/completions') {
			$tokens_count = $response_data['usage']['total_tokens'];
		}

		// Calculate the cost based on the tokens count and cost per token.
		$cost_per_token = 0.00003; // Replace this with the actual cost per token from OpenAI pricing.
		$cost = $this->calculate_cost($tokens_count, $cost_per_token);
		
        $message_str = '';
        foreach ($messages as $message) {
            $message_str .=
                'Role: ' .
                $message["role"] .
                '<br/>' .
                'Content: ' .
                $message["content"] .
                '<br/>';
        }
        $debug =
            'style ' .
            $wrtStyle .
            '<br/>tone ' .
            $wrtStone .
            '<br/>actionInput: ' .
            $actionInput .
            '<br/>max_tokens: ' .
            $max_tokens .
            '<br/>Prompt: ' .
            $send_arr["prompt"] .
            '<br/>MESSAGE: ' .
            $message_str .
            '<br/> $model: ' .
            $send_arr["model"] .
            '<br/> $model 2: ' .
            $model .
            '<br/> $apikey: ' .
            $apikey .
            '<br/> $top_p: ' .
            $send_arr["top_p"] .
            '<br/> $freq_pent: ' .
            $send_arr["frequency_penalty"] .
            '<br/> $presence_penalty: ' .
            $send_arr["presence_penalty"] .
            '<br/> $max_tokens: ' .
            $send_arr["max_tokens"] .
            '<br/> $temp: ' .
            $send_arr["temperature"] .
            '<br/> $n: ' .
            $send_arr["n"] .
            '<br/>';

        if ($response != "") {
            // Process the response and generate the output
            // Decode the JSON response into an associative array
            $resArr = json_decode($response);

            $isError = isset($resArr->error) ? $resArr->error : '';
            if (!empty($isError)) {
                $errorMSG = isset($isError->message) ? $isError->message : '';
                $resultArr['html'] = $errorMSG;
                $resultArr['type'] = "error";
            } else {
                // Check if the response is an array and combine the content
                if (isset($resArr->choices)) {
                    $combinedContent = '';
                    foreach ($resArr->choices as $choice) {
                        if (isset($choice->message->content)) {
                            $combinedContent .= $choice->message->content;
                        }
                    }
                }

                $titleHtml = '<div class="title-idea after_generate_data">';

                if (
                    $actionInput == 'evaluate' ||
                    $actionInput == 'article' ||
                    $actionInput == 'review'
                ) {
                    $titleHtml .= '<div class="ul1" ><div class="eval-screen">';
                } else {
                    $titleHtml .= '<ul class="ul1" >';
                }

                if ($resArr != "") {
                    $choicesArr = isset($resArr->choices)
                        ? $resArr->choices
                        : '';
                    $combinedContent = '';

                    if (!empty($choicesArr)) {
                        foreach ($choicesArr as $reskey => $resvalue) {
                            // Access the corresponding element in the $resArr->choices array
                            $choice = $resArr->choices[$reskey];

                            // Initialize the combinedContent variable
                            $combinedContent = '';

                            // Check if the choice message content exists and append it to the combinedContent variable
                            if (isset($choice->message->content)) {
                                $combinedContent .= $choice->message->content;
                            }

                            // Check if the resvalue text exists and append it to the combinedContent variable
                            $textRes = isset($resvalue->text)
                                ? $resvalue->text
                                : '';
                            $combinedContent .= $textRes;

                            // Now, $combinedContent contains both the choice message content and the resvalue text

                            if ($actionInput == 'keyword') {
                                if (
                                    $model == 'gpt-3.5-turbo' ||
                                    $model == 'gpt-3.5-turbo-0301'
                                ) {
                                    $combinedContent = str_replace(
                                        ",",
                                        "\n",
                                        $combinedContent
                                    );
                                }
                                $combinedContent = explode(
                                    "\n",
                                    $combinedContent
                                );
                            } elseif ($actionInput == 'heading') {
                                $combinedContent = str_replace(
                                    "\n\n",
                                    "\n",
                                    $combinedContent
                                );
                                $combinedContent = explode(
                                    "\n\n",
                                    $combinedContent
                                );
                            } elseif ($actionInput == 'conclusion') {
                                $combinedContent = explode(
                                    "\n\n",
                                    $combinedContent
                                );
                            } elseif ($actionInput == 'qna') {

                                $combinedContent = explode(
                                    "\n\n",
                                    $combinedContent
                                );
                            } elseif ($actionInput == 'seo-meta-data') {
                                $combinedContent = explode(
                                    "\n\n",
                                    $combinedContent
                                );
                            } elseif ($actionInput == 'evaluate') {
                                $combinedContent = explode(
                                    "\n\n",
                                    $combinedContent
                                );
                            } else {
                                $combinedContent = explode(
                                    "\n",
                                    $combinedContent
                                );
                            }
                            $checkboxAdded = false;

                            foreach ($combinedContent as $textValue) {
                                if (
                                    $actionInput == 'heading' ||
                                    $actionInput == 'keyword'
                                ) {
                                    $textValue = str_replace(
                                        "\n",
                                        '<br/>',
                                        $textValue
                                    );

                                }
                                if ($actionInput == 'heading') {
                                    $textValue = ltrim($textValue, "<br/>");
                                }  elseif (
                                    $actionInput == 'seo-meta-data'
                                ) {
                                    $textValue = str_replace(
                                        "\n\n",
                                        "<br/>",
                                        $textValue
                                    );
                                    $textValue = ltrim($textValue, "<br/>");
                                    $textValue = trim(
                                        str_replace(
                                            'Meta Title:',
                                            '',
                                            $textValue
                                        )
                                    );
                                    $textValue = trim(
                                        str_replace(
                                            'Meta Description:',
                                            '',
                                            $textValue
                                        )
                                    );
                                } elseif ($actionInput == 'article') {
                                    $textValue = str_replace(
                                        "·",
                                        "",
                                        $textValue
                                    );
                                } elseif ($actionInput == 'evaluate') {
                                    $textValue = str_replace(
                                        "\n",
                                        "<br/>",
                                        $textValue
                                    );
                                }
                                if ($textValue != "") {
                                    $textValue = str_replace(
                                        '"',
                                        '',
                                        $textValue
                                    );
                                    if (
                                        $actionInput == 'qna' ||
                                        $actionInput == 'conclusion'
                                    ) {
                                        $titleHtml .=
                                            ' 
                                                    <div  class= "generate-api-qna generate_' .
                                            $actionInput .
                                            ' copycontent" >
                                                    <input type="button" class="copy_button" style="width:auto; height:25px; padding:3px; margin-right:10px;" value="Copy" />
                                                    <div class="get_' .
                                            $actionInput .
                                            '"> ' .
                                            $textValue .
                                            '</div>
                                                    <input class="checkbox get_checked" id="check_' .
                                            $actionInput .
                                            '" name="get_checked" type="checkbox" value= "' .
                                            $textValue .
                                            '" />
                                                    </div>';
                                    } elseif (
                                        $actionInput == 'evaluate' ||
                                        $actionInput == 'article' ||
                                        $actionInput == 'review'
                                    ) {
                                        $textValue = preg_replace_callback(
											'/(<!--|\s*<!--)|\s+/',
											function ($matches) {
												if (isset($matches[1]) && $matches[1] !== '') {
													return $matches[1];
												} else {
													return ' ';
												}
											},
											$textValue
										);
                                        $titleHtml .= html_entity_decode(
                                            $textValue
                                        );
                                    } else {
                                        $titleHtml .=
                                            ' 
                                                    <div  class= "generate-api-article generate_' .
                                            $actionInput .
                                            ' copycontent" >
                                                    <input type="button" class="copy_button" style="width:auto; height:25px; padding:3px; margin-right:10px;" value="Copy" />
                                                    <p>' .
                                            preg_replace(
                                            	//'/^\d+[\.\)\s-]+/m',
                                                '/\d+\. /',
												'',
                                                $textValue
                                            ) . "The token cost: " . $cost . "The tokens are: " . $tokens_count . 
                                            '</p>
                                                    <input class="checkbox get_checked" id="check_' .
                                            $actionInput .
                                            '" name="get_checked" type="checkbox" value= "' .
                                            preg_replace(
                                                //'/^\d+[\.\)\s-]+/m',
                                                '/\d+\. /',
												'',
                                                $textValue
                                            ) . "The token cost: " . $cost . "The tokens are: " . $tokens_count . 
                                            '" />
                                            </div>';
                                    }
                                }
                            }
                        }
                    }
                }
    				// Add the tokens_count and cost to the result array
					//$resultArr['tokens_count'] = $tokens_count;
					//$resultArr['cost'] = $cost; 
					//$titleHtml = $titleHtml . "The tokens are: " . $cost . $tokens_count;
                if (
                    $actionInput == 'evaluate' ||
                    $actionInput == 'article' ||
                    $actionInput == 'review'
                ) {
                    $titleHtml .= '</div></div></div>';
                } else {
                    $titleHtml .= '</ul></div>';
                }
           		//$titleHtml = $debug . $titleHtml;
                $resultArr['html'] = $titleHtml;
                $articleStr = implode(" ", $combinedContent);
                $resultArr['article'] = $articleStr;
                $resultArr['type'] = "success";
			
            }
        }
		
		$http_status_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
		if ($http_status_code == 504) {
			// Handle gateway timeout error
			$resultArr['type'] = "error";
			$resultArr['message'] = "Unfortunately OpenAI is very slow today which has caused a gateway timeout error. Please try again later.";
		} else if ($http_status_code != 200) {
			// Handle other HTTP errors
			$resultArr['type'] = "error";
			$resultArr['message'] = "An error occurred while fetching data. Please try again later.";
		} 
		curl_close($curl);
        // return $resultArr;
        echo json_encode($resultArr);

        exit();
    }
}
// Initialize the class
$my_plugin = new AI_Scribe();
