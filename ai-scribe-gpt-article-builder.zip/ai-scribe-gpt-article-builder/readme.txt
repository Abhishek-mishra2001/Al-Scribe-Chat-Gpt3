=== AI-Scribe ===
Contributors: OPACE LTD, MITASH TEAM
Tags: AI, GPT, SEO, Content Creator, Article Builder, Article Generator, OpenAI, GPT-3, GPT-4, GPT-3.5, GPT-3.5-Turbo, Text Creator, Blog Creator
Requires at least: 4.4 or higher
Tested up to: 6.1
Stable tag: 1.0.0
License: GPL-3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.txt
Donate link: https://www.opace.co.uk/get-in-touch

AI-Scribe is a **ChatGPT**-powered content creation wizard that helps you generate **SEO-optimised content** for your website. This **free WordPress plugin** is available to all. 

== Description ==

AI-Scribe is a **powerful ChatGPT-powered** content creation wizard for WordPress that helps users generate SEO-optimised content for their blog posts. Designed to integrate with AI engines like **GPT-3**, **GPT-3.5 Turbo**, and **GPT-4** from OpenAI, AI-Scribe aims to streamline the content creation process by offering **editable prompts** and **suggestions** throughout the writing journey.

= Key features include =

* SEO-driven content creation
* Keyword optimisation
* Structured content generation
* Wizard-like article builder interface
* Content that passes the human and Google tests
* Configurable options for language, style, tone, headings, and additional features
* Visible prompts and ability to revise them
* Multiple usage options, including saving as a post, shortcode, or copying to clipboard
* Evaluation features to assess content quality

Please note that AI-Scribe is not a commercial plugin, and support is limited to critical issues and suggestions. To get the most out of AI-Scribe, users should follow SEO guidelines, personalise their content, and always add value to ensure the best chances of ranking in search engines.

= Caveats of Using GPT =

1. Hallucinations: AI models may generate false information or hallucinate. Verify generated facts and figures before publishing.
2. No live or real-time data: GPT models only contain information up to September 2021 and are not connected to the internet for real-time data.
3. Inconsistent responses: AI models may sometimes provide results in inconsistent or random ways due to their nature.

= SEO Guidelines =

1. Check everything including keyword usage: Ensure the content flows well and does not suffer from keyword stuffing or over-optimisation.
2. Check for duplicate content and plagiarism: Use tools like Copyscape to ensure the content is unique and not copied from other sources.
3. Personalise and add value: Make the content unique and valuable to improve its chances of being indexed and ranked by search engines.
4. AI detection tools: Be aware that AI-generated content may be detected by tools like GPTZero and OpenAI's AI Text Classifier. Personalising and refining content can help it pass as human-written.

= Feedback =

* We're am open for your suggestions and feedback and would gladly take any ideas on board. 
* Drop us a [message here](https://www.opace.co.uk/get-in-touch)
* Follow us on [Facebook](https://www.facebook.com/opacewebdesign)
* Or follow us on [Twitter](https://twitter.com/OpaceWeb)
 
= More =
* See [our WordPress.org profile page](https://profiles.wordpress.org/opacewebdesign/)
* See [our website](https://www.opace.co.uk/wordpress-agency/)

== Installation ==

1. Upload the entire 'AI-Scribe' folder to the '/wp-content/plugins/' directory of your website, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Look at your admin bar and you will see AI-Scribe displayed.
4. Add your OpenAI API key within the settings > AI Engine tab.
5. Click 'Generate Article' and start creating magical content.


== Frequently Asked Questions ==

= How does AI-Scribe use AI engines like GPT-3, GPT-3.5 Turbo, and GPT-4? =

AI-Scribe integrates with OpenAI's GPT-3, GPT-3.5 Turbo, and GPT-4 engines to generate content based on your input and preferences. It provides prompts and suggestions to help you create SEO-optimised content efficiently.

= Are there any costs associated with using AI-Scribe? =

AI-Scribe itself is free to download and use, but you will need access to OpenAI's API, which may have associated costs depending on your usage. Please check OpenAI's pricing for more details: [https://openai.com/pricing](https://openai.com/pricing)

= How can I customise the prompts in AI-Scribe? =

AI-Scribe allows you to edit prompts at each stage of the content creation process. You can use your own instructions and pre-defined shortcodes/parameters, such as [Language], [Style], and [Keywords Selected]. Custom default prompts can also be saved within the global settings page.

= How do I ensure the generated content aligns with my brand voice and tone? =

AI-Scribe provides configurable options for language, style, and tone. By selecting the appropriate settings, you can create content that matches your brand's voice and tone, ensuring a consistent user experience across your website.

= Can I use AI-Scribe with page builders like Elementor and Divi? =

Yes, AI-Scribe offers multiple usage options, including saving the content as a shortcode. This allows you to use the generated content within widgets, modules, and page builders like Elementor and Divi.

= How can I evaluate the quality of the content generated by AI-Scribe? =

AI-Scribe provides evaluation features that assess your content's quality, although these results should be taken with a pinch of salt. Future updates plan to integrate third-party tools for a more accurate and detailed evaluation.

= What if I encounter token issues while generating content? =

Token issues may occur for very long articles or when using specific AI engines. To resolve token issues, consider shortening the content or switching to a different AI engine that supports a higher token limit, like GPT-4.

= Who created the plugin? =

AI-Scribe was designed and developed by a UK based digital marketing agency called [Opace](https://www.opace.co.uk).


= Where can I get my OpenAI API key = 
If you don't have an OpenAI account yet, you can sign up for one here: [https://beta.openai.com/signup](https://beta.openai.com/signup).

Log into your OpenAI account. Click your username in the top righthand corner and select “View API keys".Then on the next screen, create or copy an API key.


== Screenshots ==

Brainstorm article titles
Find relevant keywords
Create an article outline
Write an introduction
Add a tagline
Write a conclusion
Create meta data for SEO

[youtube https://www.youtube.com/watch?v=Yl9IaX6hNVU]
[youtube https://www.youtube.com/watch?v=udoVdF2d-rs]
[youtube https://www.youtube.com/watch?v=5ybz1PtGkA8]
[youtube https://www.youtube.com/watch?v=ktCD3VS-AfA]
[youtube https://www.youtube.com/watch?v=FJSGB4dvAz8]
[youtube https://www.youtube.com/watch?v=u6qqc4IHVAM]

== Changelog ==

= 1.0.0 =
* Initial release.

== Additional Info ==

** Idea Behind AI-Scribe** To bring the OpenAI GPT technology to WordPress users as a plugin, allowing them to create keyword-led content fully optimised for SEO.

== Credits ==

* Thanks to some great prompt ideas from the community and [MITASH](https://www.mitash.com) for support building the plugin. 